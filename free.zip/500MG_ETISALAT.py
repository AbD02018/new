import requests
import base64
import xml.etree.ElementTree as ET
import time

print("Russian Bear @MYJ0P")

email = input('Enter your Email : ')
password = ("Enter your password : ")

tok = f"{email}:{password}"
token = base64.b64encode(tok.encode()).decode()

login = "https://mab.etisalat.com.eg:11003/Saytar/rest/authentication/loginWithPlan"
fox_login = """<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<loginRequest>
    <deviceId></deviceId>
    <firstLoginAttempt>false</firstLoginAttempt>
    <modelType></modelType>
    <osVersion></osVersion>
    <platform>Android</platform>
    <udid></udid>
</loginRequest>"""

headers = {
    'Host': "mab.etisalat.com.eg:11003",
    'User-Agent': "okhttp/5.0.0-alpha.11",
    'Connection': "Keep-Alive",
    'Accept': "text/xml",
    'Accept-Encoding': "gzip",
    'Content-Type': "text/xml; charset=UTF-8",
    'applicationVersion': "2",
    'applicationName': "MAB",
    'Authorization': f"Basic {token}",
    'Language': "ar",
    'APP-BuildNumber': "10650",
    'APP-Version': "33.1.0",
    'OS-Type': "Android",
    'OS-Version': "13",
    'APP-STORE': "GOOGLE",
    'C-Type': "4G",
    'Is-Corporate': "false",
    'ADRUM_1': "isMobile:true",
    'ADRUM': "isAjax:true"
}

r = requests.post(login, data=fox_login, headers=headers)
try:
 fox_xml = ET.fromstring(r.text)
 number = fox_xml.find("dial").text
except:
 print('Email or password Error ')

url = "https://mab.etisalat.com.eg:11003/Saytar/rest/servicemanagement/submitOrderV2"

payload = f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><submitOrderRequest><mabOperation></mabOperation><msisdn>{number}</msisdn><operation>REDEEM</operation><productName>DOWNLOAD_GIFT_1_SOCIAL_UNITS</productName></submitOrderRequest>"""
response = requests.post(url, data=payload, headers=headers)

print(response.text)
