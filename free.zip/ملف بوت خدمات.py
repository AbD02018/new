# Colored by KAKAROT (@XV_YX)
import sqlite3
import datetime
import telebot
from telebot import types

TOKEN = 'التوكن هنااا'
bot = telebot.TeleBot(TOKEN)

# الحصول على معرف يوزر البوت تلقائياً عند التشغيل
BOT_USERNAME = ""
try:
    BOT_USERNAME = bot.get_me().username
except:
    BOT_USERNAME = "YourBot"

user_states = {}

# --- إعداد قاعدة البيانات وتحديث الجداول ---
def init_db():
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance INTEGER DEFAULT 0,
            completed_orders INTEGER DEFAULT 0,
            invites_count INTEGER DEFAULT 0,
            referred_by INTEGER,
            last_gift_time TEXT,
            username TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS gift_codes (
            code TEXT PRIMARY KEY,
            points INTEGER,
            is_used INTEGER DEFAULT 0
        )
    ''')
    for col in [('completed_orders', 'INTEGER DEFAULT 0'), ('invites_count', 'INTEGER DEFAULT 0'), ('referred_by', 'INTEGER'), ('last_gift_time', 'TEXT'), ('username', 'TEXT')]:
        try:
            cursor.execute(f'ALTER TABLE users ADD COLUMN {col[0]} {col[1]}')
        except sqlite3.OperationalError:
            pass
    conn.commit()
    conn.close()

init_db()

def get_user_data(user_id):
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT balance, completed_orders, invites_count FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    
    if not user:
        cursor.execute('INSERT INTO users (user_id, balance, completed_orders, invites_count) VALUES (?, ?, ?, ?)', (user_id, 0, 0, 0))
        conn.commit()
        balance, completed, invites = 0, 0, 0
    else:
        balance, completed, invites = user
        
    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]
    conn.close()
    return balance, completed, invites, total_users

# دالة إنشاء القائمة الرئيسية
def main_menu_markup(user_id):
    balance, completed, _, _ = get_user_data(user_id)
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    markup.add(types.InlineKeyboardButton(f"💰 رصيدك: {balance} نقطة", callback_data="balance", style="success"))
    markup.add(types.InlineKeyboardButton("دعوة أصدقاء", callback_data="invite_friends", style="primary"),
               types.InlineKeyboardButton("هدية يومية", callback_data="daily_gift", style="primary"))
    markup.add(types.InlineKeyboardButton("كود هدية", callback_data="gift_code", style="primary"),
               types.InlineKeyboardButton("اشترك قناه", callback_data="sub_channel", style="primary"))
    markup.add(types.InlineKeyboardButton("طلب خدمة", callback_data="request_service", style="success"))
    markup.add(types.InlineKeyboardButton("طلباتي", callback_data="my_orders", style="primary"),
               types.InlineKeyboardButton("إحصائياتي", callback_data="my_stats", style="primary"))
    markup.add(types.InlineKeyboardButton("تحويل نقاط", callback_data="transfer_points", style="primary"),
               types.InlineKeyboardButton("قناه الأكواد", url="https://t.me/kingmodvip01", style="primary"))
    markup.add(types.InlineKeyboardButton(f"✅ طلبات مكتملة: {completed}", callback_data="completed_orders", style="success"))
    
    return markup

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    username = message.from_user.username
    args = message.text.split()
    
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    
    cursor.execute('UPDATE users SET username = ? WHERE user_id = ?', (username, user_id))
    conn.commit()
    
    cursor.execute('SELECT user_id, referred_by FROM users WHERE user_id = ?', (user_id,))
    existing_user = cursor.fetchone()
    
    is_new_referral_success = False
    
    if len(args) > 1 and args[1].startswith("ref_"):
        try:
            ref_id = int(args[1].replace("ref_", ""))
            if not existing_user and ref_id != user_id:
                cursor.execute('SELECT user_id FROM users WHERE user_id = ?', (ref_id,))
                if cursor.fetchone():
                    cursor.execute('INSERT INTO users (user_id, balance, referred_by, username) VALUES (?, 0, ?, ?)', (user_id, ref_id, username))
                    cursor.execute('UPDATE users SET balance = balance + 50, invites_count = invites_count + 1 WHERE user_id = ?', (ref_id,))
                    conn.commit()
                    is_new_referral_success = True
        except:
            pass
            
    if not existing_user and not is_new_referral_success:
        cursor.execute('INSERT OR IGNORE INTO users (user_id, balance, invites_count) VALUES (?, 0, 0)', (user_id,))
        conn.commit()

    conn.close()
    
    user_states.pop(user_id, None)
    balance, _, _, total_users = get_user_data(user_id)
    markup = main_menu_markup(user_id)
    
    text = (
        "🌟 أهلاً بك في بوت النقاط!\n"
        "━━━━━━━━━━━━━━\n"
        f"🆔 آيديك: {user_id}\n"
        f"💰 رصيدك: {balance} نقطة\n"
        f"👥 المستخدمون: {total_users:,}\n"
        "━━━━━━━━━━━━━━\n"
        "✨ يمكنك:\n"
        "  🎉 جمع النقاط بالدعوة والاشتراك\n"
        "  🚀 شراء خدمات بنقاطك\n"
        "  🛒 شحن النقاط بطرق متعددة\n"
        "  🔄 تحويل نقاط لأصدقائك\n"
        "━━━━━━━━━━━━━━\n"
        "👇 اختر من القائمة:"
    )
    
    if is_new_referral_success:
        bot.send_message(message.chat.id, "🎉 تم احتساب الدعوة، وصاحب الكود ربح 50 نقطة.")
        
    bot.send_message(message.chat.id, text, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "back_to_home")
def back_to_home(call):
    user_id = call.from_user.id
    user_states.pop(user_id, None)
    balance, _, _, total_users = get_user_data(user_id)
    markup = main_menu_markup(user_id)
    
    text = (
        "🌟 أهلاً بك في بوت النقاط!\n"
        "━━━━━━━━━━━━━━\n"
        f"🆔 آيديك: {user_id}\n"
        f"💰 رصيدك: {balance} نقطة\n"
        f"👥 المستخدمون: {total_users:,}\n"
        "━━━━━━━━━━━━━━\n"
        "✨ يمكنك:\n"
        "  🎉 جمع النقاط بالدعوة والاشتراك\n"
        "  🚀 شراء خدمات بنقاطك\n"
        "  🛒 شحن النقاط بطرق متعددة\n"
        "  🔄 تحويل نقاط لأصدقائك\n"
        "━━━━━━━━━━━━━━\n"
        "👇 اختر من القائمة:"
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)

# --- قسم اشتراك القنوات ---
@bot.callback_query_handler(func=lambda call: call.data == "sub_channel")
def handle_sub_channel(call):
    user_id = call.from_user.id
    user_states.pop(user_id, None)
    
    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = (
        "📭 لا توجد قنوات متاحة حالياً\n\n"
        "لا توجد طلبات اشتراك نشطة.\n"
        "حاول مجدداً لاحقاً."
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

# --- قسم طلب الخدمات ---
@bot.callback_query_handler(func=lambda call: call.data == "request_service")
def handle_request_service(call):
    user_id = call.from_user.id
    user_states.pop(user_id, None)
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("متابعين انستا • 1k/3,500", callback_data="service_insta_followers", style="success"),
        types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger")
    )
    
    text = (
        "🚀 طلب خدمة\n"
        "━━━━━━━━━━━━━━\n"
        "اختر الخدمة من الأزرار بالأسفل:"
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "service_insta_followers")
def handle_insta_followers(call):
    user_id = call.from_user.id
    user_states[user_id] = "waiting_for_insta_link"
    
    balance, _, _, _ = get_user_data(user_id)
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("رجوع للخدمات", callback_data="request_service", style="danger"))
    
    text = (
        "🛒 متابعين انستا\n"
        "━━━━━━━━━━━━━━\n"
        "متابعين انستا سريع جدا\n\n"
        "ملاحضة لاتطلب لنفس الحساب مرتين نفس الوقت\n"
        "━━━━━━━━━━━━━━\n"
        "💎 السعر: 3,500 / 1000\n"
        "📉 الحد: 100 — 100000\n"
        f"💰 رصيدك: {balance} نقطة\n"
        "━━━━━━━━━━━━━━\n"
        "🔢 أرسل العدد المطلوب:"
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "daily_gift")
def handle_daily_gift(call):
    user_id = call.from_user.id
    now = datetime.datetime.now()
    
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT balance, last_gift_time FROM users WHERE user_id = ?', (user_id,))
    row = cursor.fetchone()
    
    balance = row[0]
    last_gift_str = row[1]
    
    can_take = True
    if last_gift_str:
        last_gift_time = datetime.datetime.strptime(last_gift_str, "%Y-%m-%d %H:%M:%S")
        if now - last_gift_time < datetime.timedelta(hours=24):
            can_take = False

    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))

    if can_take:
        new_balance = balance + 100
        cursor.execute('UPDATE users SET balance = ?, last_gift_time = ? WHERE user_id = ?', 
                       (new_balance, now.strftime("%Y-%m-%d %H:%M:%S"), user_id))
        conn.commit()
        conn.close()
        
        text = (
            "╔══════════════════╗\n"
            "  🎁 الهدية اليومية\n"
            "╚══════════════════╝\n"
            "🎊 تم الحصول على هديتك!\n"
            "┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n"
            "✨ مضاف: +100 نقطة\n"
            f"💰 رصيدك: {new_balance} نقطة\n\n"
            "⏰ عد غداً للهدية التالية!"
        )
    else:
        conn.close()
        text = (
            "🎁 استلمت الهدية اليومية بالفعل!\n"
            "⏰ الهدية التالية: غداً"
        )
        
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

@bot.callback_query_handler(func=lambda call: call.data == "invite_friends")
def handle_invite_friends(call):
    user_id = call.from_user.id
    _, _, invites, _ = get_user_data(user_id)
    
    conn = sqlite3.connect('bot_database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT user_id, username, invites_count FROM users WHERE invites_count > 0 ORDER BY invites_count DESC LIMIT 6')
    top_users = cursor.fetchall()
    conn.close()
    
    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣"]
    
    top_list_text = ""
    if top_users:
        for index, (u_id, uname, u_invites) in enumerate(top_users):
            identifier = f"@{uname}" if uname else str(u_id)
            medal = medals[index] if index < len(medals) else f"{index+1}️⃣"
            top_list_text += f"{medal} {identifier} — {u_invites} دعوة\n"
    else:
        top_list_text = "لا يوجد مشاركين رابط الدعوة\n"

    referral_link = f"https://t.me/{BOT_USERNAME}?start=ref_{user_id}"
    
    invite_markup = types.InlineKeyboardMarkup(row_width=1)
    invite_markup.add(types.InlineKeyboardButton("نسخ الرابط", copy_text=types.CopyTextButton(text=referral_link, style="primary")),
                      types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = (
        "🎊 نظام الدعوة\n"
        "━━━━━━━━━━━━━━\n"
        "💰 كل دعوة = 50 نقطة\n"
        f"📊 دعواتك: {invites}\n"
        "━━━━━━━━━━━━━━\n"
        "🏆 أكثر 6 أشخاص دعوات\n"
        f"{top_list_text}"
        "━━━━━━━━━━━━━━\n"
        f"🔗 رابطك: {referral_link}\n\n"
        "👇 شارك الرابط مع أصدقائك:"
    )
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=invite_markup, disable_web_page_preview=True)

@bot.callback_query_handler(func=lambda call: call.data == "my_stats")
def handle_my_stats(call):
    user_id = call.from_user.id
    balance, completed, invites, _ = get_user_data(user_id)
    
    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = (
        "📊 إحصائياتك\n"
        "━━━━━━━━━━━━━━\n"
        f"💰 رصيدك: {balance} نقطة\n"
        f"📦 طلباتك: {completed}\n"
        f"🎉 دعواتك: {invites}"
    )
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

@bot.callback_query_handler(func=lambda call: call.data == "my_orders")
def handle_my_orders(call):
    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = "📦 لا توجد طلبات بعد."
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

@bot.callback_query_handler(func=lambda call: call.data == "gift_code")
def handle_gift_code_button(call):
    user_id = call.from_user.id
    user_states[user_id] = "waiting_for_gift_code"
    
    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = (
        "🎁 كود الهدية\n\n"
        "أرسل الكود هنا للحصول على النقاط.\n\n"
        "يمكنك الحصول على الكود من الإدارة أو من قناة البوت."
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

@bot.callback_query_handler(func=lambda call: call.data == "transfer_points")
def handle_transfer_button(call):
    user_id = call.from_user.id
    user_states[user_id] = {"step": "waiting_for_target_id"}
    
    back_markup = types.InlineKeyboardMarkup()
    back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
    
    text = (
        "╔══════════════════╗\n"
        "  💸 تحويل النقاط\n"
        "╚══════════════════╝\n\n"
        "⚠️ عمولة: 10% من المبلغ المحول\n\n"
        "👤 أرسل آيدي المستخدم المستقبل:"
    )
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_markup)

@bot.message_handler(func=lambda message: True)
def handle_text_messages(message):
    user_id = message.from_user.id
    text = message.text.strip()
    
    if user_id not in user_states:
        return
    
    state = user_states[user_id]
    
    if state == "waiting_for_gift_code":
        conn = sqlite3.connect('bot_database.db')
        cursor = conn.cursor()
        cursor.execute('SELECT points, is_used FROM gift_codes WHERE code = ?', (text,))
        code_row = cursor.fetchone()
        
        if not code_row:
            if text == "TEST100":
                cursor.execute('INSERT OR IGNORE INTO gift_codes (code, points, is_used) VALUES (?, ?, ?)', ("TEST100", 100, 0))
                conn.commit()
                cursor.execute('SELECT points, is_used FROM gift_codes WHERE code = ?', (text,))
                code_row = cursor.fetchone()
                
        if code_row:
            points, is_used = code_row
            if is_used == 1:
                bot.send_message(user_id, "❌ عذراً، هذا الكود تم استخدامه من قبل!")
            else:
                cursor.execute('UPDATE gift_codes SET is_used = 1 WHERE code = ?', (text,))
                cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (points, user_id))
                conn.commit()
                
                cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
                new_bal = cursor.fetchone()[0]
                conn.close()
                
                user_states.pop(user_id, None)
                bot.send_message(user_id, f"✅ تم شحن الكود بنجاح!\n✨ مضاف: +{points} نقطة\n💰 رصيدك الحالي: {new_bal} نقطة")
                return
        else:
            conn.close()
            bot.send_message(user_id, "❌ الكود غير صحيح أو انتهت صلاحيته!")
            return

    elif state == "waiting_for_insta_link":
        back_markup = types.InlineKeyboardMarkup()
        back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
        
        user_states.pop(user_id, None)
        bot.send_message(user_id, f"✅ تم استلام طلبك بنجاح وجاري معالجته!\n📥 النص المرسل: {text}", reply_markup=back_markup)
        return
            
    elif isinstance(state, dict):
        back_markup = types.InlineKeyboardMarkup()
        back_markup.add(types.InlineKeyboardButton("القائمة الرئيسية", callback_data="back_to_home", style="danger"))
        
        if state["step"] == "waiting_for_target_id":
            if not text.isdigit():
                bot.send_message(user_id, "❌ خطأ! يرجى إرسال آيدي صحيح (أرقام فقط):")
                return
            
            target_id = int(text)
            if target_id == user_id:
                bot.send_message(user_id, "❌ لا يمكنك تحويل نقاط لنفسك! أرسل آيدي شخص آخر:")
                return
                
            conn = sqlite3.connect('bot_database.db')
            cursor = conn.cursor()
            cursor.execute('SELECT balance FROM users WHERE user_id = ?', (target_id,))
            target_user = cursor.fetchone()
            conn.close()
            
            if not target_user:
                bot.send_message(user_id, "❌ هذا المستخدم غير مسجل في البوت. تأكد من الآيدي وأرسل مجدداً:")
                return
                
            user_states[user_id] = {"step": "waiting_for_amount", "target_id": target_id}
            bot.send_message(user_id, "💵 ممتاز! الآن أرسل عدد النقاط التي تريد تحويلها:")
            
        elif state["step"] == "waiting_for_amount":
            if not text.isdigit():
                bot.send_message(user_id, "❌ خطأ! يرجى إرسال رقم صحيح للنقاط:")
                return
                
            amount = int(text)
            if amount <= 0:
                bot.send_message(user_id, "❌ يجب أن يكون المبلغ أكبر من صفر:")
                return
                
            target_id = state["target_id"]
            balance, _, _, _ = get_user_data(user_id)
            
            if balance < amount:
                bot.send_message(user_id, f"❌ رصيدك غير كافٍ! رصيدك الحالي هو: {balance} نقطة فقط.")
                return
                
            commission = int(amount * 0.10)
            received_amount = amount - commission
            
            conn = sqlite3.connect('bot_database.db')
            cursor = conn.cursor()
            
            cursor.execute('UPDATE users SET balance = balance - ? WHERE user_id = ?', (amount, user_id))
            cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (received_amount, target_id))
            conn.commit()
            
            cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
            new_balance = cursor.fetchone()[0]
            conn.close()
            
            user_states.pop(user_id, None)
            
            bot.send_message(
                user_id,
                f"✅ تم التحويل بنجاح!\n"
                f"📤 تم إرسال: {amount} نقطة\n"
                f"📥 وصل للمستقبل: {received_amount} نقطة\n"
                f"📉 العمولة (10%): {commission} نقطة\n"
                f"💰 رصيدك الحالي: {new_balance} نقطة",
                reply_markup=back_markup
            )

print("Bot is running with Channel Subscription screen updated...")
bot.infinity_polling()