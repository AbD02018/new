import requests
import json

print("Russian Bear @MYJ0P")

url = "https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token"
number = input('Enter your number :')
password = input('Enter your password :')
payload = {
  'grant_type': "password",
  'username': number,
  'password': password,
  'client_secret': "95fd95fb-7489-4958-8ae6-d31a525cd20a",
  'client_id': "ana-vodafone-app"
}

headers = {
  'User-Agent': "okhttp/4.11.0",
  'Accept': "application/json, text/plain, */*",
  'Accept-Encoding': "gzip",
  'silentLogin': "false",
  'x-agent-operatingsystem': "13",
  'clientId': "AnaVodafoneAndroid",
  'Accept-Language': "ar",
  'x-agent-device': "Xiaomi 21061119AG",
  'x-agent-version': "2025.11.1",
  'x-agent-build': "946",
  'digitalId': "28RI9U7IINOOB"
}

response = requests.post(url, data=payload, headers=headers)
try:
	tok = response.json()['access_token']
except:
	print('number or password error ')
	exit()

url = "https://web.vodafone.com.eg/services/dxl/promo/promotion"

payload = {
  "@type": "Promo",
  "channel": {
    "id": "1"
  },
  "context": {
    "type": "youtubePromo"
  },
  "pattern": [
    {
      "characteristics": [
        {
          "name": "param1",
          "value": "30"
        },
        {
          "name": "param2",
          "value": 1
        }
      ]
    }
  ]
}

headers = {
  'User-Agent': "vodafoneandroid",
  'Accept': "application/json",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'Content-Type': "application/json",
  'sec-ch-ua-platform': "\"Android\"",
  'Authorization': f"Bearer {tok}",
  'Accept-Language': "AR",
  'msisdn': number,
  'sec-ch-ua': "\"Chromium\";v=\"142\", \"Android WebView\";v=\"142\", \"Not_A Brand\";v=\"99\"",
  'clientId': "WebsiteConsumer",
  'sec-ch-ua-mobile': "?1",
  'channel': "APP_PORTAL",
  'Origin': "https://web.vodafone.com.eg",
  'X-Requested-With': "com.emeint.android.myservices",
  'Sec-Fetch-Site': "same-origin",
  'Sec-Fetch-Mode': "cors",
  'Sec-Fetch-Dest': "empty",
}

response = requests.post(url, data=json.dumps(payload), headers=headers)
try:
	 fox_id = response.json()["id"]
	 fox_mg = response.json()["characteristics"][0]["value"]
	 fox_mg2 = response.json()["characteristics"][0]["@type"]
	 
except:
	print('لا يوجد لديك هدايا حاول بكره ')
	exit()
	

url = f"https://web.vodafone.com.eg/services/dxl/promo/promotion/{fox_id}"

payload = {
  "@type": "Promo",
  "channel": {
    "id": "1"
  },
  "context": {
    "type": "youtubePromo"
  },
  "pattern": [
    {
      "characteristics": [
        {
          "name": "shortCode",
          "value": ""
        }
      ]
    }
  ]
}

headers = {
  'User-Agent': "vodafoneandroid",
  'Accept': "application/json",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'Content-Type': "application/json",
  'sec-ch-ua-platform': "\"Android\"",
  'Authorization': f"Bearer {tok}",
  'Accept-Language': "AR",
  'msisdn': number,
  'x-dtpc': "13$56456853_816h9vCDAHAMQPKIOPIKVMWFPEHCQRGCPJEVQP-0e0",
  'clientId': "WebsiteConsumer",
  'sec-ch-ua': "\"Chromium\";v=\"142\", \"Android WebView\";v=\"142\", \"Not_A Brand\";v=\"99\"",
  'sec-ch-ua-mobile': "?1",
  'channel': "APP_PORTAL",
  'Origin': "https://web.vodafone.com.eg",
  'X-Requested-With': "com.emeint.android.myservices",
  'Sec-Fetch-Site': "same-origin",
  'Sec-Fetch-Mode': "cors",
  'Sec-Fetch-Dest': "empty",
}

response = requests.patch(url, data=json.dumps(payload), headers=headers)
if response.status_code == 204:
	print(f'done send {fox_mg}{fox_mg2} ✓')
else:
	print('حدث خطاء اثناء اضافه الهديه')
