import requests
# by: @X_Ahm_ed_X
number = input('📱 رقم الهاتف')
password = input('🔑 كلمة المرور: ')

print("🔄 جاري تسجيل الدخول...")

login_url = "https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token"
login_data = {
    'grant_type': 'password',
    'username': number,
    'password': password,
    'client_secret': '95fd95fb-7489-4958-8ae6-d31a525cd20a',
    'client_id': 'ana-vodafone-app'
}
login_headers = {
    'User-Agent': 'okhttp/4.12.0',
    'Content-Type': 'application/x-www-form-urlencoded'
}

resp = requests.post(login_url, data=login_data, headers=login_headers)

if resp.status_code == 401:
    try:
        error = resp.json()
        if 'invalid_grant' in error.get('error', ''):
            print("❌ كلمة المرور غلط. حاول مرة تانية.")
        else:
            print(f"❌ فشل تسجيل الدخول: {error.get('error_description', 'خطأ')}")
    except:
        print("❌ كلمة المرور غلط أو الرقم مش صحيح.")
    exit()

if resp.status_code != 200:
    print(f"❌ فشل الاتصال بالسيرفر (كود {resp.status_code})")
    exit()

login_result = resp.json()
# by: @X_Ahm_ed_X
if 'access_token' not in login_result:
    error_desc = login_result.get('error_description', 'خطأ')
    if 'invalid' in error_desc.lower():
        print("❌ كلمة المرور غلط. حاول مرة تانية.")
    else:
        print(f"❌ فشل تسجيل الدخول: {error_desc}")
    exit()

token = login_result['access_token']
print("✅ تم تسجيل الدخول!")

print("🔍 جاري البحث عن الهدية...")
# by: @X_Ahm_ed_X
gift_url = "https://web.vodafone.com.eg/services/dxl/promo/promotion?@type=Promo&$.context.type=worldCupStadium26"
gift_headers = {
    'Host': 'web.vodafone.com.eg',
    'Connection': 'keep-alive',
    'msisdn': number,
    'Accept-Language': 'AR',
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'clientId': 'WebsiteConsumer',
    'User-Agent': 'vodafoneandroid',
    'channel': 'APP_PORTAL',
    'Origin': 'https://web.vodafone.com.eg',
    'X-Requested-With': 'com.emeint.android.myservices',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.vodafone.com.eg/portal/bf/massWorldCup26/gifts-page'
}
# by: @X_Ahm_ed_X
gift_resp = requests.get(gift_url, headers=gift_headers)

if gift_resp.status_code != 200 or not gift_resp.text.strip():
    print(f"❌ السيرفر رجع كود خطأ ({gift_resp.status_code})")
    print(f"الرد: {gift_resp.text[:300]}")
    exit()
# by: @X_Ahm_ed_X
try:
    promos = gift_resp.json()
except:
    print(f"❌ الرد مش JSON صالح: {gift_resp.text[:300]}")
    exit()
# by: @X_Ahm_ed_X
promo_id = None
for p in promos:
    if p.get('lifecycleStatus') == '1' and p.get('id'):
        promo_id = p['id']
        print(f"🎁 تم العثور على هدية: {p.get('name', 'World Cup Gift')}")
        break

if not promo_id:
    print("ℹ️ مفيش هدايا متاحة (يمكن استلمتها قبل كده).")
    exit()
# by: @X_Ahm_ed_X
print("🚀 جاري تفعيل الهدية...")

activate_url = f"https://web.vodafone.com.eg/services/dxl/promo/promotion/{promo_id}"
activate_headers = {
    'Host': 'web.vodafone.com.eg',
    'Connection': 'keep-alive',
    'msisdn': number,
    'Accept-Language': 'AR',
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'clientId': 'WebsiteConsumer',
    'User-Agent': 'vodafoneandroid',
    'channel': 'APP_PORTAL',
    'Origin': 'https://web.vodafone.com.eg',
    'X-Requested-With': 'com.emeint.android.myservices',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.vodafone.com.eg/portal/bf/massWorldCup26/gifts-page'
}
activate_body = {
    "@type": "Promo",
    "channel": {
        "id": "5"
    },
    "context": {
        "type": "rechargePromoRevamp"
    }
}

resp = requests.patch(activate_url, headers=activate_headers, json=activate_body)

if resp.status_code == 204:
    print("🎉 تم تفعيل هدية 1000 ميجا بنجاح!")
else:
    print(f"❌ فشل التفعيل (كود {resp.status_code}): {resp.text}")