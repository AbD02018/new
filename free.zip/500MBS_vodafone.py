import requests,json
import json

print('='*30)
print("This Script By : Rottian Bear 🔥\n @MYJ0P")
print('='*30)




number = input('Enter Number')

password = input('Enter Password')

url = "https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token"

payload = {
  'grant_type': "password",
  'username': number,
  'password': password,
  'client_secret': "95fd95fb-7489-4958-8ae6-d31a525cd20a",
  'client_id': "ana-vodafone-app"
}

headers = {
  'User-Agent': "okhttp/4.12.0",
  'Accept': "application/json, text/plain, */*",
  'Accept-Encoding': "gzip",
  'silentLogin': "true",
  'x-agent-operatingsystem': "11",
  'clientId': "AnaVodafoneAndroid",
  'Accept-Language': "ar",
  'x-agent-device': "OPPO oppo6779",
  'x-agent-version': "2025.12.2",
  'x-agent-build': "1075",
  'digitalId': "2B8218UYQUHTQ",
  'device-id': "70d3004b2bd92694"
}

response = requests.post(url, data=payload, headers=headers)

if 'access_token' in response.json():
    token = response.json()['access_token']
else:
    print("الرقم او الباسورد غلط")
    exit()


url = "https://web.vodafone.com.eg/services/dxl/promo/promotion"

params = {
  '@type': "Promo",
  '$.context.type': "wowRamadan26"
}

headers = {
  'User-Agent': "vodafoneandroid",
  'Accept': "application/json",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'sec-ch-ua-platform': "\"Android\"",
  'Authorization': f"Bearer {token}",
  'Accept-Language': "AR",
  'msisdn': number,
  'sec-ch-ua': "\"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"144\", \"Android WebView\";v=\"144\"",
  'clientId': "WebsiteConsumer",
  'sec-ch-ua-mobile': "?1",
  'channel': "APP_PORTAL",
  'Content-Type': "application/json",
  'X-Requested-With': "com.emeint.android.myservices",
  'Sec-Fetch-Site': "same-origin",
  'Sec-Fetch-Mode': "cors",
  'Sec-Fetch-Dest': "empty",
  'Referer': "https://web.vodafone.com.eg/portal/bf/wow26/intro",
}



response = requests.get(url, params=params, headers=headers)
offers = response.json()


offer_id = None
for offer in offers:
    for char in offer.get("characteristics", []):
        if char.get("name") == "amount" and char.get("value") == "500":
            offer_id = offer.get("id")
            break
    if offer_id:
        break

if not offer_id:
    print("العرض مش متاح لخطك")
    exit()
        
    
    


url = f"https://web.vodafone.com.eg/services/dxl/promo/promotion/{offer_id}"

payload = {
    "@type": "Promo",
    "channel": {
        "id": "5"
    },
    "context": {
        "type": "wowRamadan26" 
    }
}

headers = {
  'User-Agent': "vodafoneandroid",
  'Accept': "application/json",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'Content-Type': "application/json",
  'sec-ch-ua-platform': "\"Android\"",
  'Authorization': f"Bearer {token}",
  'Accept-Language': "AR",
  'msisdn': number,
  'x-dtpc': "24$339460976_382h41vQTMQTILATAPEKUHFSDSMLSPMVKEOAJIP-0e0",
  'clientId': "WebsiteConsumer",
  'sec-ch-ua': "\"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"144\", \"Android WebView\";v=\"144\"",
  'sec-ch-ua-mobile': "?1",
  'channel': "APP_PORTAL",
  'Origin': "https://web.vodafone.com.eg",
  'X-Requested-With': "com.emeint.android.myservices",
  'Sec-Fetch-Site': "same-origin",
  'Sec-Fetch-Mode': "cors",
  'Sec-Fetch-Dest': "empty",
  'Referer': "https://web.vodafone.com.eg/portal/bf/wow26/contact-details",
}

response = requests.patch(url, data=json.dumps(payload), headers=headers)

if response.status_code == 204:
	print('تم اضافة 500 ميجا لخطك')
else:
	print('العرض مش متاح لخطك')


