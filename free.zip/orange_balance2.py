import requests
import json

# ========== بيانات تسجيل الدخول ==========
url_login = "https://services.orange.eg/SignIn.svc/SignInUser"

headers_login = {
    "IsEasyLogin": "false",
    "AppVersion": "10.2.0",
    "OSVersion": "9",
    "IsAndroid": "true",
    "Token": "",
    "Content-Type": "application/json; charset=UTF-8",
    "Host": "services.orange.eg",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
    "User-Agent": "okhttp/4.12.0"
}

payload_login = {
    "appVersion": "10.2.0",
    "channel": {
        "ChannelName": "MobinilAndMe",
        "ChannelPassword": "ig3yh*mk5l42@oj7QAR8yF"
    },
    "dialNumber": input("Number: "),
    "isAndroid": True,
    "Language": "ar",
    "password": input("Password: ")
}

# ========== دوال جلب الرصيد ==========

def get_consumption(access_token, dial_number):
    """جلب الاستهلاك الأساسي (وحدات، باقات كارت الكبير)"""
    url = "https://services.orange.eg/PostpaidInfoService.svc/GetConsumption"
    headers = {
        "Token": access_token,
        "Content-Type": "application/json; charset=UTF-8",
        "Host": "services.orange.eg",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.12.0"
    }
    payload = {
        "channel": {
            "ChannelName": "MobinilAndMe",
            "Password": "ig3yh*mk5l42@oj7QAR8yF"
        },
        "dial": dial_number,
        "isCoin": False,
        "isDarkMode": False,
        "lang": "ar",
        "rpCode": "20",
        "serviceClassId": "313",
        "isEasyLogin": True,
        "password": "k2#ejq5uG5"
    }

    print("\n📡 جاري جلب بيانات الاستهلاك الأساسي...")
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        result = data.get("GetConsumptionResult", {})
        if result.get("ErrorCode") == 0:
            units = result.get("Units", [])
            print("\n✅ بيانات الاستهلاك الأساسي:")
            print("-" * 50)
            for unit in units:
                title = unit.get("Title", "بدون عنوان")
                remaining = unit.get("Remaining", 0.0)
                uom = unit.get("UOMString", "")
                # تنسيق الأرقام
                if remaining == int(remaining):
                    remaining_str = str(int(remaining))
                else:
                    remaining_str = f"{remaining:.2f}"
                print(f"📌 {title}: {remaining_str} {uom}")
            print("-" * 50)
        else:
            print(f"❌ فشل جلب الاستهلاك: {result.get('ErrorDescription')}")
    except Exception as e:
        print(f"❌ خطأ في طلب الاستهلاك: {e}")

def get_buckets(access_token, dial_number):
    """جلب الباقات النشطة (الهدايا، الرصيد الإضافي)"""
    url = "https://backend.orange.eg/api/Buckets/GetAllActivatedBuckets"
    headers = {
        "Token": access_token,
        "Content-Type": "application/json; charset=UTF-8",
        "Host": "backend.orange.eg",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.12.0"
    }
    payload = {
        "automate": True,
        "channel": {
            "ChannelName": "MobinilAndMe",
            "Password": "ig3yh*mk5l42@oj7QAR8yF"
        },
        "dial": dial_number,
        "handleMobileIssue": True,
        "lang": "ar",
        "isEasyLogin": True,
        "password": "k2#ejq5uG5"
    }

    print("\n📡 جاري جلب الباقات النشطة (الهدايا والإضافات)...")
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        result = data.get("GetAllActivatedBucketsResult", {})
        if result.get("ErrorCode") == 0:
            buckets = result.get("Buckets", [])
            if not buckets:
                print("⚠️ لا توجد باقات نشطة حالياً.")
                return

            print("\n✅ الباقات النشطة:")
            print("-" * 60)
            for bucket in buckets:
                name = bucket.get("BucketName", "بدون اسم")
                bucket_id = bucket.get("BucketID", "")
                remaining = bucket.get("RemainingValue", "0")
                unit = bucket.get("RemainingValueUnit", "")
                expiry = bucket.get("ExpiryDate", "غير محدد")
                category = bucket.get("Category", "")
                
                # تنسيق الرصيد (قد يكون نصاً أو رقماً)
                try:
                    rem_float = float(remaining) if remaining else 0.0
                    if rem_float == int(rem_float):
                        rem_str = str(int(rem_float))
                    else:
                        rem_str = f"{rem_float:.2f}"
                except:
                    rem_str = remaining

                print(f"📦 {name} (ID: {bucket_id})")
                if category:
                    print(f"   الفئة: {category}")
                print(f"   الرصيد المتبقي: {rem_str} {unit}")
                if expiry and expiry != "غير محدد":
                    print(f"   تاريخ الانتهاء: {expiry}")
                print("-" * 60)
        else:
            print(f"❌ فشل جلب الباقات: {result.get('ErrorDescription')}")
    except Exception as e:
        print(f"❌ خطأ في طلب الباقات: {e}")

# ========== الدالة الرئيسية ==========

def main():
    print("جاري إرسال طلب تسجيل الدخول...\n")
    try:
        response = requests.post(url_login, headers=headers_login, json=payload_login, timeout=10)
        response.raise_for_status()
        response_data = response.json()

        sign_in_result = response_data.get("SignInUserResult", {})
        if sign_in_result.get("ErrorCode") == 0:
            user_data = sign_in_result.get("UserData", {})
            first_name = user_data.get("FirstName", "مستخدم")
            access_token = sign_in_result.get("AccessToken", "")
            dial = user_data.get("Dial", payload_login["dialNumber"])

            print("\n" + "="*40)
            print(f"مرحباً بك: {first_name} {user_data.get('LastName', '')}")
            print(f"رقم الهاتف: {dial}")
            print(f"Access Token (أول 30 حرف): {access_token[:30]}...")
            print("="*40)

            # جلب الرصيد
            get_consumption(access_token, dial)
            get_buckets(access_token, dial)

        else:
            print(f"\n❌ فشل تسجيل الدخول: {sign_in_result.get('ErrorDescription')}")

    except Exception as e:
        print(f"❌ حدث خطأ: {e}")

if __name__ == "__main__":
    main()
