import requests
import base64
import xml.etree.ElementTree as ET
def main():
    email = input('Enter your Email: ')
    password = input('Enter your Password: ')
    token = base64.b64encode(f"{email}:{password}".encode()).decode()
    headers = {
        'Host': "mab.etisalat.com.eg:11003",
        'User-Agent': "okhttp/5.0.0-alpha.11",
        'Connection': "Keep-Alive",
        'Accept': "text/xml",
        'Accept-Encoding': "gzip",
        'Content-Type': "text/xml; charset=UTF-8",
        'applicationVersion': "2",
        'applicationName': "MAB",
        'Authorization': f"Basic {token}",
        'Language': "ar",
        'APP-BuildNumber': "10650",
        'APP-Version': "33.1.0",
        'OS-Type': "Android",
        'OS-Version': "13",
        'APP-STORE': "GOOGLE",
        'C-Type': "4G",
        'Is-Corporate': "false",
        'ADRUM_1': "isMobile:true",
        'ADRUM': "isAjax:true"
    }
    login_url = "https://mab.etisalat.com.eg:11003/Saytar/rest/authentication/loginWithPlan"
    login_payload = """<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
    <loginRequest>
        <deviceId></deviceId>
        <firstLoginAttempt>false</firstLoginAttempt>
        <modelType></modelType>
        <osVersion></osVersion>
        <platform>Android</platform>
        <udid></udid>
    </loginRequest>"""
    try:
        response = requests.post(login_url, data=login_payload, headers=headers, timeout=30)
        response.raise_for_status()
        root = ET.fromstring(response.text)
        number = root.find("dial").text       
        if not number:
            raise ValueError("Could not find phone number in response")         
    except Exception as e:
        print(f'Login failed: {e}')
        return
    print("\nPlease select a service to activate:")
    print("1. SHAHID_HYBRID_VIP")
    print("2. TWIST_TV_HARDBUNDLE")
    print("3. TWIST_MUSIC_HARDBUNDLE")
    print("4. VIU_MONTHLY_RENEWAL")
    print("5. TOD_MONTHLY_MOBILE_RENEWAL")   
    choice = input("Enter your choice (1-5): ")
    services = {
        "1": {
            "name": "SHAHID_HYBRID_VIP",
            "payload": f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <generalSubmitOrderRequest>
                <category></category>
                <contactDial></contactDial>
                <msisdn>{number}</msisdn>
                <operation>ACTIVATE</operation>
                <passParameters />
                <productName>SHAHID_HYBRID_VIP</productName>
                <requestId></requestId>
                <type></type>
            </generalSubmitOrderRequest>"""
        },
        "2": {
            "name": "TWIST_TV_HARDBUNDLE",
            "payload": f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <generalSubmitOrderRequest>
                <category></category>
                <contactDial></contactDial>
                <msisdn>{number}</msisdn>
                <operation>ACTIVATE</operation>
                <passParameters />
                <productName>TWIST_TV_HARDBUNDLE</productName>
                <requestId></requestId>
                <type></type>
            </generalSubmitOrderRequest>"""
        },
        "3": {
            "name": "TWIST_MUSIC_HARDBUNDLE",
            "payload": f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <generalSubmitOrderRequest>
                <category></category>
                <contactDial></contactDial>
                <msisdn>{number}</msisdn>
                <operation>ACTIVATE</operation>
                <passParameters />
                <productName>TWIST_MUSIC_HARDBUNDLE</productName>
                <requestId></requestId>
                <type></type>
            </generalSubmitOrderRequest>"""
        },
        "4": {
            "name": "VIU_MONTHLY_RENEWAL",
            "payload": f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <generalSubmitOrderRequest>
                <category></category>
                <contactDial></contactDial>
                <msisdn>{number}</msisdn>
                <operation>ACTIVATE</operation>
                <passParameters />
                <productName>VIU_MONTHLY_RENEWAL</productName>
                <requestId></requestId>
                <type></type>
            </generalSubmitOrderRequest>"""
        },
        "5": {
            "name": "TOD_MONTHLY_MOBILE_RENEWAL",
            "payload": f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <generalSubmitOrderRequest>
                <category></category>
                <contactDial></contactDial>
                <msisdn>{number}</msisdn>
                <operation>ACTIVATE</operation>
                <passParameters />
                <productName>TOD_MONTHLY_MOBILE_RENEWAL</productName>
                <requestId></requestId>
                <type></type>
            </generalSubmitOrderRequest>"""
        }
    }    
    if choice not in services:
        print("Invalid choice!")
        return    
    selected_service = services[choice]    
    order1_url = "https://mab.etisalat.com.eg:11003/Saytar/rest/digitalIncentive/submitOrderV2"
    order1_payload = f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
    <digitalincentiveSubmitOrderRequest>
        <operation>ACTIVATE_MIGRATE</operation>
        <parameterList />
        <productId>YOUDA_BUNDLE_10</productId>
        <subscriberNumber>{number}</subscriberNumber>
    </digitalincentiveSubmitOrderRequest>"""
    try:
        response1 = requests.post(order1_url, data=order1_payload, headers=headers, timeout=30)
        response1.raise_for_status()
        print("First order (YOUDA_BUNDLE_10) successful")
    except Exception as e:
        print(f'First order failed: {e}')
    order2_url = "https://mab.etisalat.com.eg:11003/Saytar/rest/General/submitOrder"    
    try:
        response2 = requests.post(order2_url, data=selected_service["payload"], headers=headers, timeout=30)
        response2.raise_for_status()
        print(f"{selected_service['name']} activation successful")
        print(response2.text)
    except Exception as e:
        print(f'Service activation failed: {e}')
if __name__ == "__main__":
    main()