import os, sys, time, base64, requests
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
import pyfiglet
required_modules = ['pyfiglet', 'requests', 'bs4']
for module in required_modules:
    try:
        __import__(module)
    except ImportError:
        os.system(f'pip install {module}')
Z, G, A, C, B, F, R, Y, Bl, P, cC, W, PN, X = [
    '\x1b[2;31m', '\x1b[1;32m', '\x1b[2;39m', '\x1b[2;35m', '\x1b[2;36m',
    '\033[2;32m', '\033[1;31m', '\033[1;33m', '\033[1;34m', '\033[1;35m',
    '\033[1;36m', '\033[1;37m', '\033[1;35m', '\033[1;33m']
border = "\033[92;1m═\033[1;35m═\033[1;34m═\033[1;33m═\033[1;32m═\033[1;97m═\033[38;5;196m═\033[1;35m═\033[1;34m═\033[1;33m═\033[1;33m═\033[1;97m═\033[38;5;196m═\033[38;5;196m═\033[1;33m═\033[1;33m═\033[1;32m═\033[1;34m═\033[1;33m═\033[1;97m═\033[38;5;196m═\033[1;97m═\033[38;5;196m═\033[38;5;196m══\033[1;33m══\033[1;35m══\033[1;34m══\033[1;33m═\033[1;97m═\033[38;5;196m═\033[1;97m═\033[1;97m═\033[1;32m═\033[1;34m═\033[1;33m══\033[1;35m═\033[1;34m══\033[1;34m══\033[38;5;196m═\033[1;97m═\033[1;33m══\033[1;34m═\033[1;32m═\033[1;35m═\033[1;34m═\033[1;33m═\033[1;33m═\033[1;35m═\033[1;33m═\033[1;34m═\033[1;36m═\033[1;36m═"
print(border)
print('                𝐒𝐂𝐑𝐈𝐏𝐓 𝐅𝐑𝐄𝐄 𝐍𝐞𝐭 𝐄𝐭𝐢𝐬𝐚𝐥𝐚𝐭 ')
print(border)
print(Z + pyfiglet.figlet_format(' 2 Hour '))
print(f'{C}        ✨Hello in my script✨ ')
print(border)
print(f'                LOGIN  ')
print(border)
number = input(f'{R} [{C}+{R}] {Y}𝔼𝕟𝕥𝕖𝕣 𝕪𝕠𝕦𝕣 𝕟𝕦𝕞𝕓𝕖𝕣   {R} :{G} ')
password = input(f'{R} [{C}+{R}] {Y}𝔼𝕟𝕥𝕖𝕣 𝕪𝕠𝕦𝕣 𝕡𝕒𝕤𝕤𝕨𝕠𝕣𝕕 {R} :{G} ')
email = input(f'{R} [{C}+{R}] {Y}𝔼𝕟𝕥𝕖𝕣 𝕪𝕠𝕦𝕣 𝔾𝕞𝕒𝕚𝕝    {R} :{G} ')
def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.02)
jalan(f'{Y}---------> {P}Wait{Y}.{R}.{G}.{C}.{P}.{W}.{G}.{Y} <---------')
def fox():
    num = number[1:] if "011" in number else number
    auth = "Basic " + base64.b64encode(f"{email}:{password}".encode()).decode() 
    headerslog = {
        "applicationVersion": "2", "applicationName": "MAB", "Accept": "text/xml",
        "Authorization": auth, "APP-BuildNumber": "964", "APP-Version": "27.0.0",
        "OS-Type": "Android", "OS-Version": "12", "APP-STORE": "GOOGLE",
        "Is-Corporate": "false", "Content-Type": "text/xml; charset=UTF-8",
        "Content-Length": "1375", "Host": "mab.etisalat.com.eg:11003",
        "Connection": "Keep-Alive", "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/5.0.0-alpha.11", "ADRUM_1": "isMobile:true",
        "ADRUM": "isAjax:true"}
    log = requests.post(
        "https://mab.etisalat.com.eg:11003/Saytar/rest/authentication/loginWithPlan",
        headers=headerslog,
        data="<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><loginRequest><deviceId></deviceId><firstLoginAttempt>true</firstLoginAttempt><modelType></modelType><osVersion></osVersion><platform>Android</platform><udid></udid></loginRequest>") 
    if "true" in log.text:
        ck, br = log.headers["Set-Cookie"].split(";")[0], log.headers["auth"]
        url = f"https://mab.etisalat.com.eg:11003/Saytar/rest/zero11/offersV3?req=<dialAndLanguageRequest><subscriberNumber>{num}</subscriberNumber><language>1</language></dialAndLanguageRequest>"     
        headers = {
            'applicationVersion': "2", 'Content-Type': "text/xml", 'applicationName': "MAB",
            'Accept': "text/xml", 'Language': "ar", 'APP-BuildNumber': "10459",
            'APP-Version': "29.9.0", 'OS-Type': "Android", 'OS-Version': "11",
            'APP-STORE': "GOOGLE", 'auth': "Bearer " + br, 'Host': "mab.etisalat.com.eg:11003",
            'Is-Corporate': "false", 'Connection': "Keep-Alive", 'Accept-Encoding': "gzip",
            'User-Agent': "okhttp/5.0.0-alpha.11", 'Cookie': ck}     
        response = requests.get(url, headers=headers)
        offer_id = None
        if response.status_code == 200:
            root = ET.fromstring(response.text)
            for category in root.findall('.//mabCategory'):
                for product in category.findall('.//mabProduct'):
                    for parameter in product.findall('.//fulfilmentParameter'):
                        if parameter.find('name').text == 'Offer_ID':
                            offer_id = parameter.find('value').text
                            break
                    if offer_id: break
                if offer_id: break
        else:
            print(f"{Bl}response {R}:{Y} انت اخت العرض النهارده🧚‍♂️.")       
        headerssub = {
            "applicationVersion": "2", "applicationName": "MAB", "Accept": "text/xml",
            "Cookie": ck, "Language": "ar", "APP-BuildNumber": "964", "APP-Version": "27.0.0",
            "OS-Type": "Android", "OS-Version": "12", "APP-STORE": "GOOGLE",
            "auth": "Bearer " + br, "Is-Corporate": "false", "Content-Type": "text/xml; charset=UTF-8",
            "Content-Length": "1375", "Host": "mab.etisalat.com.eg:11003", "Connection": "Keep-Alive",
            "User-Agent": "okhttp/5.0.0-alpha.11"}        
        subs = requests.post(
            "https://mab.etisalat.com.eg:11003/Saytar/rest/zero11/submitOrder",
            headers=headerssub,
            data=f"<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><submitOrderRequest><mabOperation></mabOperation><msisdn>{num}</msisdn><operation>ACTIVATE</operation><parameters><parameter><name>GIFT_FULLFILMENT_PARAMETERS</name><value>Offer_ID:{offer_id};ACTIVATE:True;isRTIM:Y</value></parameter></parameters><productName>FAN_ZONE_HOURLY_BUNDLE</productName></submitOrderRequest>"
        ).text       
        print(f"{Bl}response{R} : {G}مبرووك تم اضافه ساعتين نت لخطك 🧚." if "true" in subs else f"{Bl}[{C}+{Bl}]{R}Error {C}: اتاكد من بياناتك وحاول تاني  ")
    else:
        print(f"{Bl}[{C}+{Bl}]{R}Wrong Number or password  ")
fox()