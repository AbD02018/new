import requests
import json

# -------------------- دالة تسجيل الدخول --------------------
def login(dial_number, password):
    url_login = "https://services.orange.eg/SignIn.svc/SignInUser"
    
    headers_login = {
        "IsEasyLogin": "false",
        "AppVersion": "10.2.0",
        "OSVersion": "9",
        "IsAndroid": "true",
        "Token": "",
        "Content-Type": "application/json; charset=UTF-8",
        "Host": "services.orange.eg",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.12.0"
    }
    
    payload_login = {
        "appVersion": "10.2.0",
        "channel": {
            "ChannelName": "MobinilAndMe",
            "ChannelPassword": "ig3yh*mk5l42@oj7QAR8yF"
        },
        "dialNumber": dial_number,
        "isAndroid": True,
        "Language": "ar",
        "password": password
    }
    
    try:
        response = requests.post(url_login, headers=headers_login, json=payload_login, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        result = data.get("SignInUserResult", {})
        if result.get("ErrorCode") != 0:
            print(f"❌ فشل تسجيل الدخول: {result.get('ErrorDescription', 'خطأ غير معروف')}")
            return None
        
        access_token = result.get("AccessToken")
        if not access_token:
            print("❌ لم يتم استلام AccessToken")
            return None
        
        print("✅ تم تسجيل الدخول بنجاح")
        return access_token, response.cookies  # نعيد الكوكيز للاستخدام في الطلب التالي
        
    except Exception as e:
        print(f"❌ خطأ أثناء تسجيل الدخول: {e}")
        return None

# -------------------- دالة طلب الهدية --------------------
def redeem_gift(dial_number, token, code, session=None):
    url_redeem = "https://services.orange.eg/APIs/Promotions/api/SummerOffer/SharingRedeemGift"
    
    headers_redeem = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; Infinix X650C Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36",
        "Origin": "https://services.orange.eg",
        "Referer": f"https://services.orange.eg/Pages/summer-offer/shareWithFreinds?dial={dial_number}&language=ar&token={token}&source=summer26_false",
        "X-Requested-With": "com.orange.mobinilandme",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive"
    }
    
    payload_redeem = {
        "Dial": dial_number,
        "Language": "ar",
        "Token": token,
        "Code": code
    }
    
    try:
        # استخدام الجلسة إن وُجدت للحفاظ على الكوكيز
        if session:
            response = session.post(url_redeem, headers=headers_redeem, json=payload_redeem, timeout=15)
        else:
            response = requests.post(url_redeem, headers=headers_redeem, json=payload_redeem, timeout=15)
        
        response.raise_for_status()
        data = response.json()
        
        print("\n📦 رد الخادم:")
        print(json.dumps(data, indent=4, ensure_ascii=False))
        
        if data.get("ErrorCode") == 0:
            print("✅ تم استلام الهدية بنجاح!")
        else:
            print(f"❌ فشل الطلب: {data.get('ErrorDescription', 'خطأ غير معروف')}")
        
        return data
        
    except Exception as e:
        print(f"❌ خطأ أثناء طلب الهدية: {e}")
        return None

# -------------------- الدالة الرئيسية --------------------
def main():
    print("=" * 50)
    print("  طلب استلام هدية عرض الصيف - Orange")
    print("=" * 50)
    
    dial = input("📱 أدخل رقم الهاتف : ").strip()
    if not dial:
        print("❌ الرقم مطلوب")
        return
    
    password = input("🔑 أدخل كلمة المرور: ").strip()
    if not password:
        print("❌ كلمة المرور مطلوبة")
        return
    
    # رمز الهدية (يمكن تركه ثابتاً أو جعله اختيارياً)
    code = input("🎁 أدخل رمز الهدية (اضغط Enter للاستخدام الافتراضي '10788888888'): ").strip()
    if not code:
        code = "10788888888"
        print(f"   سيتم استخدام الرمز: {code}")
    
    # 1. تسجيل الدخول
    login_result = login(dial, password)
    if not login_result:
        return
    
    access_token, cookies = login_result
    
    # 2. إنشاء جلسة وحفظ الكوكيز
    session = requests.Session()
    session.cookies.update(cookies)
    
    # 3. طلب الهدية
    print("\n⏳ جاري إرسال طلب استلام الهدية...")
    redeem_gift(dial, access_token, code, session)

if __name__ == "__main__":
    main()
