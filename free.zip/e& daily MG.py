import requests
import base64
import xml.etree.ElementTree as ET

def make_headers(token):
    return {
        'Host': "mab.etisalat.com.eg:11003",
        'User-Agent': "okhttp/5.0.0-alpha.11",
        'Connection': "Keep-Alive",
        'Accept': "text/xml",
        'Accept-Encoding': "gzip",
        'Content-Type': "text/xml; charset=UTF-8",
        'applicationVersion': "2",
        'applicationName': "MAB",
        'Authorization': f"Basic {token}",
        'Language': "ar",
        'APP-BuildNumber': "10650",
        'APP-Version': "33.1.0",
        'OS-Type': "Android",
        'OS-Version': "13",
        'APP-STORE': "GOOGLE",
        'C-Type': "4G",
        'Is-Corporate': "false",
        'ADRUM_1': "isMobile:true",
        'ADRUM': "isAjax:true"
    }

def login_and_get_number(email, password):
    tok = f"{email}:{password}"
    token = base64.b64encode(tok.encode()).decode()
    headers = make_headers(token)

    fox_login = """<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
    <loginRequest>
        <deviceId></deviceId>
        <firstLoginAttempt>false</firstLoginAttempt>
        <modelType></modelType>
        <osVersion></osVersion>
        <platform>Android</platform>
        <udid></udid>
    </loginRequest>"""

    r = requests.post(
        "https://mab.etisalat.com.eg:11003/Saytar/rest/authentication/loginWithPlan",
        data=fox_login,
        headers=headers,
        timeout=15
    )

    try:
        xml = ET.fromstring(r.text)
        dial = xml.find("dial")
        if dial is None or dial.text is None:
            raise Exception("❌ فشل تسجيل الدخول")
        return dial.text, token
    except ET.ParseError:
        raise Exception("❌ رد السيرفر مش XML صالح")

def submit_gift(number, gift_id, amount, token):
    url_submit = "https://mab.etisalat.com.eg:11003/Saytar/rest/dailyTipsWS/submitOrder"
    payload = f"""<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<dailyTipsSubmitRequest>
    <operationId>REDEEM</operationId>
    <params>
        <param><name>GIFT_ID</name><value>{gift_id}</value></param>
        <param><name>AMOUNT</name><value>{amount}</value></param>
        <param><name>GIFT_TYPE</name><value>DailyTip</value></param>
        <param><name>GIFT_CATEGORY</name><value>Main</value></param>
    </params>
    <productId>DAILY_TIPS_GIFT</productId>
    <subscriberNumber>{number}</subscriberNumber>
</dailyTipsSubmitRequest>"""
    headers_submit = make_headers(token)
    headers_submit['Content-Type'] = "text/xml; charset=UTF-8"

    response_submit = requests.post(url_submit, data=payload, headers=headers_submit)
    try:
        xml_submit = ET.fromstring(response_submit.text)
        status = xml_submit.find("status")
        if status is not None and status.text.lower() == "true":
            print(f"✅ تم تفعيل {amount} ميجات سوشيال بنجاح ❤️‍🔥")
        else:
            print("❌ فشل التفعيل")
    except ET.ParseError:
        print("❌ رد السيرفر مش XML صالح")

if __name__ == "__main__":
    email = input("📧 Enter your email: ")
    password = input("🔑 Enter your password: ")

    try:
        number, token = login_and_get_number(email, password)
        print("✅ تسجيل الدخول نجح")
        print(f"📱 رقم الخط: {number}")
        print(f"🔑 التوكن: {token}")

        url_gift = f"https://mab.etisalat.com.eg:11003/Saytar/rest/dailyTipsWS/dailyTipsExtraGift?req=%3CdialAndLanguageRequest%3E%3CsubscriberNumber%3E{number}%3C%2FsubscriberNumber%3E%3Clanguage%3E1%3C%2Flanguage%3E%3C%2FdialAndLanguageRequest%3E"
        headers_gift = make_headers(token)
        response_gift = requests.get(url_gift, headers=headers_gift)
        root = ET.fromstring(response_gift.text)

        daily_gifts = root.findall(".//dailyGift")
        activated_found = False

        for gift in daily_gifts:
            redeemed = gift.find("redeemed").text.lower()
            params = gift.find("params")
            gift_id_elem = params.find(".//param[name='GIFT_ID']/value") if params is not None else None
            amount_elem = params.find(".//param[name='AMOUNT']/value") if params is not None else None
            gift_id = gift_id_elem.text if gift_id_elem is not None else None
            amount = amount_elem.text if amount_elem is not None else None

            if redeemed == "true":
                print(f"🎁 GIFT_ID {gift_id} - {amount} ميجات متفعل بالفعل ✅")
                activated_found = True
            elif redeemed == "false" and activated_found:
                print(f"⚡ بدء تفعيل الهديّة التالية: GIFT_ID {gift_id} - {amount} ميجات")
                submit_gift(number, gift_id, amount, token)
                break

    except Exception as e:
        print(str(e))