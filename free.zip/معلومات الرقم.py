import requests
import json
import re
import threading
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# ========== الإعدادات ==========
BOT_TOKEN = "8978067741:AAF0HOz5Vx5T3Zor48-EHrvO3GLp61kFFu8"

# قنوات الاشتراك الإجباري
REQUIRED_CHANNELS = [
    "https://t.me/selva_card",
    "https://t.me/JX_Codez",
]

# استخراج usernames من الروابط
CHANNEL_USERNAMES = []
for ch in REQUIRED_CHANNELS:
    username = ch.replace("https://t.me/", "").replace("@", "")
    CHANNEL_USERNAMES.append(username)

# تخزين حالة المستخدمين
user_data = {}  # {user_id: {"subscribed": bool, "phone": str, "code": str, "step": str}}

# ========== كلاس البحث ==========
class CallerSearchBot:
    def __init__(self):
        self.base_url = "https://caller-uegx.vercel.app/api/search"
        self.facebook_url = "https://caller-uegx.vercel.app/api/facebook/search"
        self.headers = {
            'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36",
            'Accept-Encoding': "gzip, deflate, br, zstd",
            'Content-Type': "application/json",
            'sec-ch-ua-platform': '"Android"',
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            'sec-ch-ua-mobile': "?1",
            'origin': "https://caller-uegx.vercel.app",
            'sec-fetch-site': "same-origin",
            'sec-fetch-mode': "cors",
            'sec-fetch-dest': "empty",
            'referer': "https://caller-uegx.vercel.app/",
            'accept-language': "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7",
            'priority': "u=1, i",
            'Cookie': "sin_user_id=fbab07cc323cf1a9"
        }

    def _format_phone(self, phone):
        phone = re.sub(r'[^0-9]', '', phone)
        if phone.startswith('01') and len(phone) == 11:
            return phone[1:]
        elif len(phone) == 10:
            return phone
        return phone

    def search_phone(self, phone, code="20"):
        formatted_phone = self._format_phone(phone)
        payload = {"code": code, "phone": formatted_phone}
        
        try:
            response = requests.post(
                self.base_url, 
                data=json.dumps(payload), 
                headers=self.headers,
                timeout=15
            )
            
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            print(f"Error: {e}")
            return None

    def search_facebook(self, phone, code="20"):
        formatted_phone = self._format_phone(phone)
        payload = {"code": code, "phone": formatted_phone}
        
        try:
            response = requests.post(
                self.facebook_url, 
                data=json.dumps(payload), 
                headers=self.headers,
                timeout=15
            )
            
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            print(f"Error: {e}")
            return None

# ========== دوال التحقق من الاشتراك ==========
async def check_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """التحقق إذا المستخدم مشترك في كل القنوات"""
    for username in CHANNEL_USERNAMES:
        try:
            member = await context.bot.get_chat_member(chat_id=f"@{username}", user_id=user_id)
            if member.status in ['left', 'kicked']:
                return False
        except Exception:
            return False
    return True

def get_subscription_keyboard():
    """إنشاء كيبورد الاشتراك"""
    keyboard = []
    for i, ch in enumerate(REQUIRED_CHANNELS, 1):
        keyboard.append([InlineKeyboardButton(f"📢 قناة {i}", url=ch)])
    keyboard.append([InlineKeyboardButton("✅ تحقق من الاشتراك", callback_data="verify_sub")])
    return InlineKeyboardMarkup(keyboard)

def get_main_keyboard():
    """كيبورد البحث الرئيسي"""
    keyboard = [
        [InlineKeyboardButton("🔍 بحث عام", callback_data="search_general")],
        [InlineKeyboardButton("📘 بحث فيسبوك", callback_data="search_facebook")],
        [InlineKeyboardButton("🌍 تغيير كود الدولة", callback_data="change_code")],
    ]
    return InlineKeyboardMarkup(keyboard)

def get_code_keyboard():
    """كيبورد اختيار كود الدولة"""
    keyboard = [
        [InlineKeyboardButton("🇪🇬 مصر (+20)", callback_data="code_20")],
        [InlineKeyboardButton("🇸🇦 السعودية (+966)", callback_data="code_966")],
        [InlineKeyboardButton("🇦🇪 الإمارات (+971)", callback_data="code_971")],
        [InlineKeyboardButton("🇮🇶 العراق (+964)", callback_data="code_964")],
        [InlineKeyboardButton("🇯🇴 الأردن (+962)", callback_data="code_962")],
        [InlineKeyboardButton("🇱🇧 لبنان (+961)", callback_data="code_961")],
        [InlineKeyboardButton("🇾🇪 اليمن (+967)", callback_data="code_967")],
        [InlineKeyboardButton("🔙 رجوع", callback_data="back_main")],
    ]
    return InlineKeyboardMarkup(keyboard)

# ========== معالجات الأوامر ==========
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # التحقق من الاشتراك
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        text = """⚠️ <b>عذراً عزيزي!</b>

يجب الاشتراك في القنوات التالية لاستخدام البوت:

👇 اضغط على الروابط ثم اضغط "تحقق من الاشتراك" ✅"""
        await update.message.reply_text(text, reply_markup=get_subscription_keyboard(), parse_mode="HTML")
        return
    
    # المستخدم مشترك
    if user_id not in user_data:
        user_data[user_id] = {"subscribed": True, "code": "20", "step": "idle"}
    
    welcome_text = """🎉 <b>أهلاً بك في بوت البحث عن الأرقام!</b>

🔍 يمكنك البحث عن أي رقم هاتف والحصول على المعلومات المتاحة.

📌 <b>كود الدولة الحالي:</b> +{code}

اختر نوع البحث:""".format(code=user_data[user_id]["code"])
    
    await update.message.reply_text(welcome_text, reply_markup=get_main_keyboard(), parse_mode="HTML")

async def verify_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    is_subscribed = await check_subscription(user_id, context)
    
    if is_subscribed:
        user_data[user_id] = {"subscribed": True, "code": "20", "step": "idle"}
        welcome_text = """🎉 <b>تم التحقق بنجاح!</b>

✅ أنت الآن مشترك في جميع القنوات.

🔍 يمكنك البحث عن أي رقم هاتف والحصول على المعلومات المتاحة.

📌 <b>كود الدولة الحالي:</b> +20

اختر نوع البحث:"""
        await query.edit_message_text(welcome_text, reply_markup=get_main_keyboard(), parse_mode="HTML")
    else:
        await query.answer("❌ لم تشترك في جميع القنوات بعد!", show_alert=True)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    
    # التحقق من الاشتراك أولاً
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await query.edit_message_text(
            "⚠️ <b>يجب الاشتراك في القنوات أولاً!</b>",
            reply_markup=get_subscription_keyboard(),
            parse_mode="HTML"
        )
        return
    
    data = query.data
    
    if data == "search_general":
        user_data[user_id]["step"] = "waiting_phone_general"
        await query.edit_message_text(
            f"📱 <b>أرسل الرقم للبحث العام</b>\n\n"
            f"🌍 كود الدولة: +{user_data[user_id]['code']}\n"
            f"💡 مثال: 01123456789 أو 1112345678",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="back_main")]]),
            parse_mode="HTML"
        )
    
    elif data == "search_facebook":
        user_data[user_id]["step"] = "waiting_phone_facebook"
        await query.edit_message_text(
            f"📘 <b>أرسل الرقم للبحث في فيسبوك</b>\n\n"
            f"🌍 كود الدولة: +{user_data[user_id]['code']}\n"
            f"💡 مثال: 01123456789 أو 1112345678",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="back_main")]]),
            parse_mode="HTML"
        )
    
    elif data == "change_code":
        await query.edit_message_text(
            "🌍 <b>اختر كود الدولة:</b>",
            reply_markup=get_code_keyboard(),
            parse_mode="HTML"
        )
    
    elif data.startswith("code_"):
        code = data.replace("code_", "")
        user_data[user_id]["code"] = code
        await query.edit_message_text(
            f"✅ <b>تم تغيير كود الدولة إلى: +{code}</b>",
            reply_markup=get_main_keyboard(),
            parse_mode="HTML"
        )
    
    elif data == "back_main":
        user_data[user_id]["step"] = "idle"
        await query.edit_message_text(
            f"🔍 <b>اختر نوع البحث:</b>\n\n📌 كود الدولة الحالي: +{user_data[user_id]['code']}",
            reply_markup=get_main_keyboard(),
            parse_mode="HTML"
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # التحقق من الاشتراك
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text(
            "⚠️ <b>يجب الاشتراك في القنوات أولاً!</b>",
            reply_markup=get_subscription_keyboard(),
            parse_mode="HTML"
        )
        return
    
    if user_id not in user_data:
        user_data[user_id] = {"subscribed": True, "code": "20", "step": "idle"}
    
    step = user_data[user_id].get("step", "idle")
    phone = update.message.text.strip()
    
    if step in ["waiting_phone_general", "waiting_phone_facebook"]:
        # تنفيذ البحث
        bot_search = CallerSearchBot()
        code = user_data[user_id]["code"]
        
        searching_msg = await update.message.reply_text("⏳ <b>جاري البحث...</b>", parse_mode="HTML")
        
        if step == "waiting_phone_general":
            result = bot_search.search_phone(phone, code)
            search_type = "🔍 البحث العام"
        else:
            result = bot_search.search_facebook(phone, code)
            search_type = "📘 بحث فيسبوك"
        
        if result:
            # تنسيق النتيجة
            response_text = f"""{search_type}
📱 الرقم: <code>{phone}</code>
🌍 كود الدولة: +{code}
━━━━━━━━━━━━━━━
"""
            if isinstance(result, dict):
                for key, value in result.items():
                    if value and value != "null" and value != "":
                        response_text += f"📌 <b>{key}:</b> <code>{value}</code>\n"
            elif isinstance(result, list):
                for i, item in enumerate(result, 1):
                    response_text += f"\n📋 نتيجة #{i}:\n"
                    if isinstance(item, dict):
                        for key, value in item.items():
                            if value:
                                response_text += f"   <b>{key}:</b> <code>{value}</code>\n"
            else:
                response_text += f"\n📝 <code>{json.dumps(result, ensure_ascii=False, indent=2)}</code>"
        else:
            response_text = f"""❌ <b>لم يتم العثور على نتائج</b>

📱 الرقم: <code>{phone}</code>
🌍 كود الدولة: +{code}

💡 جرب رقم آخر أو تأكد من صحة الرقم."""
        
        await searching_msg.delete()
        await update.message.reply_text(response_text, reply_markup=get_main_keyboard(), parse_mode="HTML")
        user_data[user_id]["step"] = "idle"
    
    else:
        await update.message.reply_text(
            "👋 <b>أهلاً بك!</b> اختر نوع البحث:",
            reply_markup=get_main_keyboard(),
            parse_mode="HTML"
        )

# ========== التشغيل ==========
def main():
    print("🤖 تشغيل البوت...")
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    # الأوامر
    application.add_handler(CommandHandler("start", start))
    
    # Callbacks
    application.add_handler(CallbackQueryHandler(verify_subscription, pattern="^verify_sub$"))
    application.add_handler(CallbackQueryHandler(handle_callback))
    
    # الرسائل
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    print("✅ البوت يعمل الآن!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
