
#programmer : @X_Ahm_ed_X


import requests
import json
from colorama import init, Fore, Style
#programmer : @X_Ahm_ed_X

init(autoreset=True)

def get_token(msisdn, password):
    
    url = "https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token"
    
    payload = {
        'grant_type': "password",
        'username': msisdn,
        'password': password,
        'client_secret': "dca0pbLUWXVhXR266Gw1iT5rqwvvJQoN",
        'client_id': "AnaVF"
    }
    
    headers = {
        'User-Agent': "okhttp/4.12.0",
        'Accept': "application/json, text/plain, */*",
        'Accept-Encoding': "gzip",
        'silentLogin': "true",
        'msisdn': msisdn,
        'x-agent-operatingsystem': "15",
        'clientId': "AnaVodafoneAndroid",
        'Accept-Language': "ar",
        'x-agent-device': "OPPO CPH2565",
        'x-agent-version': "2026.4.1",
        'x-agent-build': "1139",
        'digitalId': "28LZHSGCX7QC4",
        'device-id': "aba8140ecd392169"
    }
    
    print(f"{Fore.YELLOW}🔄 جاري تسجيل الدخول...{Style.RESET_ALL}")
    
    try:
        response = requests.post(url, data=payload, headers=headers)
        
        print(f"{Fore.CYAN}📡 Login Status: {response.status_code}{Style.RESET_ALL}")
        
        if response.status_code == 200:
            try:
                token = response.json()['access_token']
                print(f"{Fore.GREEN}✅ تم تسجيل الدخول بنجاح!{Style.RESET_ALL}")
                return token
            except:
                print(f"{Fore.RED}❌ رقم أو كلمة سر غلط{Style.RESET_ALL}")
                return None
        else:
            print(f"{Fore.RED}❌ فشل تسجيل الدخول: {response.text}{Style.RESET_ALL}")
            return None
            
    except Exception as e:
        print(f"{Fore.RED}⚠️ خطأ: {str(e)}{Style.RESET_ALL}")
        return None
#programmer : @X_Ahm_ed_X

def change_password(current_password, new_password, bearer_token, msisdn):
    
    url = "https://mobile.vodafone.com.eg/services/dxl/sam/serviceAccountManagement/v1/serviceAccount"
    
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "api-version": "v2",
        "device-id": "aba8140ecd392169",  
        "x-agent-operatingsystem": "15",
        "clientId": "AnaVodafoneAndroid",
        "x-agent-device": "OPPO CPH2565",
        "x-agent-version": "2026.4.1",
        "x-agent-build": "1139",
        "msisdn": msisdn,
        "Accept": "application/json",
        "Accept-Language": "ar",
        "Content-Type": "application/json; charset=UTF-8",
        "Host": "mobile.vodafone.com.eg",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.12.0"
    }
    
    payload = {
        "customerAccount": {
            "authentication": {
                "newPassword": new_password,
                "password": current_password
            }
        },
        "resources": [
            {
                "IDs": [{"value": msisdn}],
                "resourceType": "MSISDN"
            }
        ],
        "@type": "userPrefsUpdate"
    }
    
    print(f"\n{Fore.YELLOW}🔄 جاري تغيير كلمة السر...{Style.RESET_ALL}")
    
    try:
        response = requests.patch(url, headers=headers, json=payload)
        
        print(f"{Fore.CYAN}📡 Status Code: {response.status_code}{Style.RESET_ALL}")
        
        if response.status_code == 200:
            print(f"{Fore.MAGENTA}{'=' * 60}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}✅ تم تغيير كلمة السر بنجاح!{Style.RESET_ALL}")
            print(f"{Fore.CYAN}📱 الرقم: {Fore.WHITE}{msisdn}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}🔑 كلمة السر الجديدة: {Fore.WHITE}{new_password}{Style.RESET_ALL}")
            print(f"{Fore.MAGENTA}{'=' * 60}{Style.RESET_ALL}")
            return True
        elif response.status_code == 401:
            print(f"{Fore.RED}❌ التوكن منتهي الصلاحية{Style.RESET_ALL}")
        elif response.status_code == 400:
            print(f"{Fore.RED}❌ خطأ في البيانات: {response.text}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}❌ فشل: {response.status_code} - {response.text}{Style.RESET_ALL}")
        return False
        
    except Exception as e:
        print(f"{Fore.RED}⚠️ خطأ: {str(e)}{Style.RESET_ALL}")
        return False
#programmer : @X_Ahm_ed_X


if __name__ == "__main__":
    print(f"{Fore.MAGENTA}{'=' * 60}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}🔐 تغيير كلمة سر فودافون{Style.RESET_ALL}")
    print(f"{Fore.MAGENTA}{'=' * 60}{Style.RESET_ALL}")
    
    msisdn = input(f"{Fore.YELLOW}📱 رقمك: {Style.RESET_ALL}").strip()
    current_password = input(f"{Fore.YELLOW}🔑 كلمة السر الحالية: {Style.RESET_ALL}").strip()
    new_password = input(f"{Fore.YELLOW}🆕 كلمة السر الجديدة: {Style.RESET_ALL}").strip()
    
    print(f"\n{Fore.MAGENTA}{'=' * 60}{Style.RESET_ALL}")
    
    #programmer : @X_Ahm_ed_X
    token = get_token(msisdn, current_password)
    
    if token:
        
        success = change_password(current_password, new_password, token, msisdn)
        
        if not success:
            print(f"\n{Fore.RED}❌ فشل تغيير كلمة السر{Style.RESET_ALL}")
    else:
        print(f"\n{Fore.RED}❌ فشل تسجيل الدخول{Style.RESET_ALL}")