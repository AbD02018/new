const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const bcrypt = require('bcrypt');
const session = require('express-session');
const config = require('./config');
const http = require('http');
const socketIo = require('socket.io');
const paymentService = require('./services/paymentService');
const TronService = require('./services/tronService');
const tronService = new TronService();
const dbService = require('./services/databaseService');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});
const PORT = process.env.PORT || 5000;
const DATA_FILE = path.join(__dirname, 'data.json');

// Ensure data.json exists
if (!fs.existsSync(DATA_FILE)) {
  const initialData = { users: [], deposits: [], withdrawals: [] };
  fs.writeFileSync(DATA_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
  console.log('Created initial data.json file');
}

// Session configuration
app.use(session({
  secret: config.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Investment plans
const PLANS = {
  VIP_0: 0,
  VIP_1: 1,
  VIP_2: 2.5,
  VIP_3: 4,
  VIP_4: 8,
  VIP_5: 10,
  VIP_6: 15,
  VIP_7: 25,
  VIP_8: 35,
  VIP_9: 60,
  VIP_10: 85,
  VIP_11: 100,
  VIP_Bronze: 200,
  VIP_Silver: 400,
  VIP_Golden: 700,
  VIP_Diamond: 1000
};

// Data operations
let dataLock = false;
const dataQueue = [];

async function withDataLock(operation) {
  return new Promise((resolve, reject) => {
    dataQueue.push({ operation, resolve, reject });
    processQueue();
  });
}

async function processQueue() {
  if (dataLock || dataQueue.length === 0) return;
  dataLock = true;

  const { operation, resolve, reject } = dataQueue.shift();
  try {
    const result = await operation();
    resolve(result);
  } catch (error) {
    reject(error);
  } finally {
    dataLock = false;
    processQueue();
  }
}

function readData() {
  if (!fs.existsSync(DATA_FILE)) {
    const initialData = { users: [], deposits: [], withdrawals: [] };
    writeDataSync(initialData);
    return initialData;
  }

  try {
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    return parsed.users ? parsed : { users: parsed, deposits: [], withdrawals: [] };
  } catch {
    return { users: [], deposits: [], withdrawals: [] };
  }
}

function writeDataSync(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function generateReferralCode() {
  return Math.random().toString(36).substr(2, 8).toUpperCase();
}

function getClientIP(req) {
  return req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip;
}

function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ message: "غير مصرح له" });
  }
  next();
}

// Socket.IO handling
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Authentication APIs
app.post('/api/register', async (req, res) => {
  const { username, email, phone, password, referralCode, securityQuestions } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "البريد الإلكتروني وكلمة المرور مطلوبان" });
  }

  if (!securityQuestions || !securityQuestions.pet || !securityQuestions.friend || 
      !securityQuestions.car) {
    return res.status(400).json({ message: "جميع الأسئلة الأمنية مطلوبة" });
  }

  try {
    const result = await withDataLock(async () => {
      const data = readData();

      if (data.users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error("البريد الإلكتروني موجود بالفعل");
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const userReferralCode = generateReferralCode();

      const newUser = {
        id: Date.now().toString(),
        username: username || email.split('@')[0],
        email,
        phone: phone || '',
        passwordHash: hashedPassword,
        plan: "VIP_0",
        balance: 0,
        trc20: null,
        referralCode: userReferralCode,
        referredBy: referralCode || null,
        referrals: [],
        ipHistory: [getClientIP(req)],
        lastWithdrawalAt: null,
        dayCounter: 0,
        pendingReferralGate: false,
        registeredAt: new Date().toISOString(),
        withdrawalHistory: [],
        securityQuestions: {
          pet: securityQuestions.pet.toLowerCase().trim(),
          friend: securityQuestions.friend.toLowerCase().trim(),
          car: securityQuestions.car.toLowerCase().trim()
        },
        tempReferralInfo: referralCode ? { code: referralCode, pending: true } : null
      };

      data.users.push(newUser);
      writeDataSync(data);
      return newUser;
    });

    res.status(201).json({ 
      message: "تم تسجيل المستخدم بنجاح",
      referralCode: result.referralCode
    });
  } catch (error) {
    res.status(409).json({ message: error.message });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "البريد الإلكتروني وكلمة المرور مطلوبان" });
  }

  console.log('🔐 محاولة تسجيل دخول بالإيميل:', email);

  const data = readData();
  const user = data.users.find(u => u.email && u.email.toLowerCase().trim() === email.toLowerCase().trim());

  if (!user) {
    console.log('❌ لم يتم العثور على المستخدم بالإيميل:', email);
    console.log('📋 الإيميلات الموجودة في النظام:', data.users.map(u => u.email));
    return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
  }

  console.log('✅ تم العثور على المستخدم:', user.id);
  console.log('🔑 نوع كلمة المرور المخزنة:', user.passwordHash ? 'مُشفرة' : 'غير مُشفرة');

  let validPassword = false;

  try {
    if (user.passwordHash) {
      validPassword = await bcrypt.compare(password, user.passwordHash);
      console.log('🔐 مقارنة كلمة المرور المُشفرة:', validPassword ? 'صحيحة' : 'خاطئة');
    } else if (user.password && user.password === password) {
      validPassword = true;
      console.log('🔐 مقارنة كلمة المرور غير المُشفرة: صحيحة');
      // Update to hashed password
      try {
        await withDataLock(async () => {
          const data = readData();
          const userIndex = data.users.findIndex(u => u.id === user.id);
          if (userIndex !== -1) {
            const hashedPassword = await bcrypt.hash(password, 10);
            data.users[userIndex].passwordHash = hashedPassword;
            delete data.users[userIndex].password;
            writeDataSync(data);
            console.log('🔄 تم تحديث كلمة المرور إلى مُشفرة');
          }
        });
      } catch (error) {
        console.error('❌ خطأ في تشفير كلمة المرور:', error);
      }
    } else {
      console.log('❌ كلمة المرور غير متطابقة مع المخزنة');
    }
  } catch (error) {
    console.error('❌ خطأ في مقارنة كلمة المرور:', error);
    return res.status(500).json({ message: "خطأ في النظام" });
  }

  if (!validPassword) {
    console.log('❌ فشل تسجيل الدخول - كلمة المرور غير صحيحة');
    return res.status(401).json({ message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
  }

  console.log('🎉 تم تسجيل الدخول بنجاح للمستخدم:', user.id);
  req.session.userId = user.id;
  res.json({ 
    message: "تم تسجيل الدخول بنجاح",
    user: {
      id: user.id,
      email: user.email,
      plan: user.plan
    }
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: "تم تسجيل الخروج بنجاح" });
});

// Password reset APIs
app.post('/api/forgot-password-security', async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ message: "البريد الإلكتروني مطلوب" });
  }

  try {
    const data = readData();
    const user = data.users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase());

    if (!user || !user.securityQuestions) {
      return res.status(404).json({ message: "لم يتم العثور على حساب أو أسئلة أمنية" });
    }

    res.json({
      success: true,
      questions: [
        "ما هو حيوانك المفضل؟",
        "ما هو اسم صديقك المفضل؟",
        "ما هو نوع السيارة التي تحبها؟"
      ]
    });
  } catch (error) {
    res.status(500).json({ message: "حدث خطأ أثناء جلب الأسئلة الأمنية" });
  }
});

app.post('/api/reset-password-security', async (req, res) => {
  const { email, answers, newPassword } = req.body;

  if (!email || !answers || !newPassword) {
    return res.status(400).json({ message: "جميع الحقول مطلوبة" });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" });
  }

  try {
    const data = readData();
    const user = data.users.find(u => u.email && u.email.toLowerCase() === email.toLowerCase());

    if (!user || !user.securityQuestions) {
      return res.status(404).json({ message: "المستخدم أو الأسئلة الأمنية غير موجودة" });
    }

    const correctAnswers = [
      answers[0] && answers[0].toLowerCase().trim() === user.securityQuestions.pet,
      answers[1] && answers[1].toLowerCase().trim() === user.securityQuestions.friend,
      answers[2] && answers[2].toLowerCase().trim() === user.securityQuestions.car
    ];

    const correctCount = correctAnswers.filter(Boolean).length;

    if (correctCount < 3) {
      return res.status(400).json({ 
        message: `الأجوبة غير صحيحة. يجب الإجابة بشكل صحيح على جميع الأسئلة الثلاثة` 
      });
    }

    await withDataLock(async () => {
      const data = readData();
      const userIndex = data.users.findIndex(u => u.id === user.id);

      if (userIndex !== -1) {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        data.users[userIndex].passwordHash = hashedPassword;
        if (data.users[userIndex].password) {
          delete data.users[userIndex].password;
        }
        writeDataSync(data);
      }
    });

    res.json({ 
      message: "تم تحديث كلمة المرور بنجاح",
      correctAnswers: correctCount
    });
  } catch (error) {
    res.status(500).json({ message: "حدث خطأ أثناء تحديث كلمة المرور" });
  }
});

// User profile APIs
app.get('/api/me', requireAuth, (req, res) => {
  const data = readData();
  const user = data.users.find(u => u.id === req.session.userId);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  const now = new Date();
  const lastWithdrawal = user.lastWithdrawalAt ? new Date(user.lastWithdrawalAt) : null;
  const nextEligibleAt = lastWithdrawal ? new Date(lastWithdrawal.getTime() + 24 * 60 * 60 * 1000) : now;

  res.json({
    id: user.id,
    email: user.email,
    plan: user.plan || "VIP_0",
    trc20: user.trc20,
    dayCounter: user.dayCounter || 0,
    pendingReferralGate: user.pendingReferralGate || false,
    lastWithdrawalAt: user.lastWithdrawalAt,
    nextEligibleAtISO: nextEligibleAt.toISOString(),
    canWithdraw: now >= nextEligibleAt && !user.pendingReferralGate && user.plan !== "VIP_0",
    dailyProfit: PLANS[user.plan] || 0,
    referralCode: user.referralCode
  });
});

// Current user endpoint
app.get('/api/current-user', (req, res) => {
  let user = null;

  if (req.session.userId) {
    const data = readData();
    user = data.users.find(u => u.id === req.session.userId);
  }

  if (user) {
    res.json({
      id: user.id,
      username: user.username || user.email?.split('@')[0] || 'مستخدم',
      email: user.email,
      referralCount: user.referrals?.length || 0,
      balance: user.balance || 0,
      plan: user.plan,
      accountId: `MRC-${user.id.toString().padStart(5, '0')}`
    });
  } else {
    res.json({
      id: '00000',
      username: 'مستخدم تجريبي',
      email: 'demo@example.com',
      referralCount: 0,
      balance: 0,
      plan: null,
      accountId: 'MRC-00000'
    });
  }
});

// Subscription APIs
app.post('/api/subscribe', requireAuth, async (req, res) => {
  const { plan } = req.body;

  if (!plan || !PLANS[plan] || plan === "VIP_0") {
    return res.status(400).json({ message: "خطة غير صالحة" });
  }

  try {
    await withDataLock(async () => {
      const data = readData();
      const userIndex = data.users.findIndex(u => u.id === req.session.userId);

      if (userIndex === -1) {
        throw new Error("المستخدم غير موجود");
      }

      const user = data.users[userIndex];
      const subscribedPlanValue = PLANS[plan];

      // تحديث خطة المستخدم
      data.users[userIndex].plan = plan;

      // التحقق من الإحالة المعلقة وتفعيلها
      if (user.tempReferralInfo && user.tempReferralInfo.pending) {
        const referrerCode = user.tempReferralInfo.code;
        const referrerIndex = data.users.findIndex(u => u.referralCode === referrerCode);

        if (referrerIndex !== -1) {
          const referrer = data.users[referrerIndex];
          const referrerPlanValue = PLANS[referrer.plan] || 0;

          // تحقق: هل الخطة المشترك فيها مساوية أو أعلى من خطة المُحيل؟
          if (subscribedPlanValue >= referrerPlanValue) {
            // إحالة ناجحة - إضافة للإحالات
            if (!data.users[referrerIndex].referrals) {
              data.users[referrerIndex].referrals = [];
            }

            data.users[referrerIndex].referrals.push({
              userId: user.id,
              email: user.email,
              date: new Date().toISOString(),
              active: true,
              plan: plan
            });

            // تحديث referredBy للمستخدم الجديد
            data.users[userIndex].referredBy = referrerCode;

            // إزالة pendingReferralGate من المُحيل إذا كان موجودًا
            if (data.users[referrerIndex].pendingReferralGate) {
              data.users[referrerIndex].pendingReferralGate = false;
            }

            // إزالة المعلومات المؤقتة
            delete data.users[userIndex].tempReferralInfo;

            console.log(`✅ إحالة ناجحة: ${user.email} أحيل بواسطة ${referrer.email} (خطة ${plan} >= ${referrer.plan})`);
          } else {
            // الخطة أقل من المطلوب - الإحالة غير ناجحة
            console.log(`❌ إحالة فاشلة: ${user.email} - الخطة ${plan} أقل من ${referrer.plan}`);
            delete data.users[userIndex].tempReferralInfo;
          }
        } else {
          // المُحيل غير موجود
          delete data.users[userIndex].tempReferralInfo;
        }
      }

      writeDataSync(data);
    });

    res.json({ message: `تم الاشتراك في ${plan} بنجاح` });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Set withdrawal password
app.post('/api/set-withdrawal-password', requireAuth, async (req, res) => {
  const { password } = req.body;

  if (!password || password.length < 6) {
    return res.status(400).json({ message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
  }

  try {
    await withDataLock(async () => {
      const data = readData();
      const userIndex = data.users.findIndex(u => u.id === req.session.userId);

      if (userIndex === -1) {
        throw new Error('المستخدم غير موجود');
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      data.users[userIndex].withdrawalPasswordHash = hashedPassword;
      writeDataSync(data);
    });

    res.json({ message: 'تم تعيين كلمة مرور السحب بنجاح' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Payment APIs
app.post('/api/initiate-payment', requireAuth, async (req, res) => {
  const { plan } = req.body;

  if (!plan || !config.INVESTMENT_PLANS[plan] || plan === 'VIP_0') {
    return res.status(400).json({ message: 'خطة غير صالحة' });
  }

  try {
    const planData = config.INVESTMENT_PLANS[plan];
    const result = await paymentService.createPendingPayment(
      req.session.userId,
      plan,
      planData.minInvestment
    );

    if (!result.success) {
      return res.status(500).json({ message: result.error });
    }

    res.json({
      success: true,
      paymentAddress: result.paymentAddress,
      amount: result.amount,
      plan: result.plan,
      expiresAt: result.expiresAt,
      network: 'TRC20 (TRON)',
      currency: 'USDT',
      message: 'يرجى إرسال المبلغ المحدد إلى عنوان المحفظة خلال 30 دقيقة'
    });
  } catch (error) {
    console.error('Error initiating payment:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء إنشاء طلب الدفع' });
  }
});

app.get('/api/payment-info/:plan', requireAuth, (req, res) => {
  const { plan } = req.params;
  const result = paymentService.getPaymentInfo(plan);

  if (!result.success) {
    return res.status(400).json({ message: result.error });
  }

  res.json(result);
});

app.get('/api/company-wallet-balance', requireAuth, async (req, res) => {
  try {
    const data = readData();
    const user = data.users.find(u => u.id === req.session.userId);
    
    // Only allow admin users (you can add an isAdmin field to user)
    // For now, just return the balance
    const result = await paymentService.getCompanyWalletBalance();
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'حدث خطأ أثناء جلب رصيد المحفظة' 
    });
  }
});

// Withdrawal APIs
app.post('/api/withdraw-daily', requireAuth, async (req, res) => {
  const { trc20, withdrawalPassword } = req.body;

  if (!trc20 || !trc20.startsWith('T')) {
    return res.status(400).json({ message: "عنوان TRC20 غير صالح" });
  }

  try {
    const data = readData();
    const user = data.users.find(u => u.id === req.session.userId);

    if (!user) {
      return res.status(404).json({ message: "المستخدم غير موجود" });
    }

    // التحقق من كلمة مرور السحب
    if (user.withdrawalPasswordHash) {
      if (!withdrawalPassword) {
        return res.status(400).json({ message: "كلمة مرور السحب مطلوبة" });
      }

      const validPassword = await bcrypt.compare(withdrawalPassword, user.withdrawalPasswordHash);
      if (!validPassword) {
        return res.status(400).json({ message: "كلمة مرور السحب غير صحيحة" });
      }
    } else if (withdrawalPassword) {
      return res.status(400).json({ message: "لم يتم تعيين كلمة مرور سحب بعد" });
    }

    if (user.plan === "VIP_0") {
      return res.status(400).json({ message: "يجب الاشتراك في خطة استثمار أولاً" });
    }

    if (user.pendingReferralGate) {
      return res.status(400).json({ message: "يجب إحالة شخص يشترك في خطة مساوية أو أعلى للمتابعة" });
    }

    const now = new Date();
    if (user.lastWithdrawalAt) {
      const lastWithdrawal = new Date(user.lastWithdrawalAt);
      const timeDiff = now - lastWithdrawal;
      const hoursPassed = timeDiff / (1000 * 60 * 60);

      if (hoursPassed < 24) {
        const hoursLeft = Math.ceil(24 - hoursPassed);
        return res.status(400).json({ message: `يمكن السحب بعد ${hoursLeft} ساعة` });
      }
    }

    const dailyProfit = PLANS[user.plan];

    // استخدام paymentService للسحب الحقيقي
    console.log(`🔄 Processing real withdrawal for user ${user.id}: ${dailyProfit} USDT`);
    const withdrawalResult = await paymentService.processWithdrawal(
      user.id,
      trc20,
      dailyProfit
    );

    if (!withdrawalResult.success) {
      return res.status(500).json({ message: withdrawalResult.error });
    }

    // السحب تم بنجاح
    res.json({
      success: true,
      message: `تم صرف ${withdrawalResult.amount} USDT إلى ${trc20}`,
      amount: withdrawalResult.amount,
      fee: withdrawalResult.fee,
      txid: withdrawalResult.txid,
      explorerLink: withdrawalResult.explorerLink
    });
  } catch (error) {
    console.error('Error in withdrawal:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء معالجة السحب' });
  }
});

// Remove old mock withdrawal continuation
app.post('/api/withdraw-daily-old', requireAuth, async (req, res) => {
  const { trc20, withdrawalPassword } = req.body;

  if (!trc20 || !trc20.startsWith('T')) {
    return res.status(400).json({ message: "عنوان TRC20 غير صالح" });
  }

  try {
    const result = await withDataLock(async () => {
      const data = readData();
      const userIndex = data.users.findIndex(u => u.id === req.session.userId);

      if (userIndex === -1) {
        throw new Error("المستخدم غير موجود");
      }

      const user = data.users[userIndex];

      // التحقق من كلمة مرور السحب
      if (user.withdrawalPasswordHash) {
        if (!withdrawalPassword) {
          throw new Error("كلمة مرور السحب مطلوبة");
        }

        const validPassword = await bcrypt.compare(withdrawalPassword, user.withdrawalPasswordHash);
        if (!validPassword) {
          throw new Error("كلمة مرور السحب غير صحيحة");
        }
      } else if (withdrawalPassword) {
        // إذا لم يكن لديه كلمة مرور محفوظة لكن أدخل واحدة
        throw new Error("لم يتم تعيين كلمة مرور سحب بعد");
      }

      if (user.plan === "VIP_0") {
        throw new Error("يجب الاشتراك في خطة استثمار أولاً");
      }

      if (user.pendingReferralGate) {
        throw new Error("يجب إحالة شخص يشترك في خطة مساوية أو أعلى للمتابعة");
      }

      const now = new Date();
      if (user.lastWithdrawalAt) {
        const lastWithdrawal = new Date(user.lastWithdrawalAt);
        const timeDiff = now - lastWithdrawal;
        const hoursPassed = timeDiff / (1000 * 60 * 60);

        if (hoursPassed < 24) {
          const hoursLeft = Math.ceil(24 - hoursPassed);
          throw new Error(`يمكن السحب بعد ${hoursLeft} ساعة`);
        }
      }

      user.trc20 = trc20;
      const dailyProfit = PLANS[user.plan];

      if (!user.withdrawalHistory) {
        user.withdrawalHistory = [];
      }

      user.withdrawalHistory.push({
        id: Date.now().toString(),
        type: 'daily_profit',
        amount: dailyProfit,
        address: trc20,
        status: 'completed',
        createdAt: now.toISOString(),
        processedAt: now.toISOString()
      });

      user.lastWithdrawalAt = now.toISOString();
      user.dayCounter += 1;

      if (user.dayCounter === 2) {
        user.pendingReferralGate = true;
      }

      writeDataSync(data);
      return { amount: dailyProfit, address: trc20 };
    });

    res.json({ 
      success: true,
      message: `تم صرف ${result.amount} USDT إلى ${result.address}`,
      amount: result.amount
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Withdrawal history
app.get('/api/withdrawal-history', requireAuth, (req, res) => {
  const data = readData();
  const user = data.users.find(u => u.id === req.session.userId);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  const withdrawalHistory = user.withdrawalHistory || [];

  res.json({
    success: true,
    withdrawals: withdrawalHistory.map(w => ({
      id: w.id,
      type: w.type,
      amount: w.amount,
      address: w.address ? `${w.address.substring(0, 10)}...${w.address.substring(-8)}` : '',
      status: w.status,
      createdAt: w.createdAt,
      processedAt: w.processedAt
    }))
  });
});

// Other APIs
app.get('/api/referral-link', requireAuth, (req, res) => {
  const data = readData();
  const user = data.users.find(u => u.id === req.session.userId);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  const baseUrl = req.protocol + '://' + req.get('host');
  const referralLink = `${baseUrl}/?ref=${user.referralCode}`;

  res.json({
    referralCode: user.referralCode,
    referralLink: referralLink,
    totalReferrals: user.referrals ? user.referrals.length : 0,
    activeReferrals: user.referrals ? user.referrals.filter(r => r.active).length : 0,
    pendingReferralGate: user.pendingReferralGate || false,
    userPlan: user.plan
  });
});

// Get referrals status
app.get('/api/referrals/status', requireAuth, (req, res) => {
  const data = readData();
  const user = data.users.find(u => u.id === req.session.userId);

  if (!user) {
    return res.status(404).json({ message: "المستخدم غير موجود" });
  }

  const referrals = (user.referrals || []).map(ref => {
    const referredUser = data.users.find(u => u.id === ref.userId);
    return {
      ...ref,
      username: referredUser?.username || 'مستخدم محذوف',
      currentPlan: referredUser?.plan || 'غير محدد'
    };
  });

  res.json({
    referrals,
    totalReferrals: referrals.length,
    activeReferrals: referrals.filter(r => r.active).length,
    pendingReferralGate: user.pendingReferralGate || false,
    userPlan: user.plan,
    dayCounter: user.dayCounter || 0
  });
});

// Add referral processing in registration
app.post('/api/process-referral', requireAuth, async (req, res) => {
  const { referralCode } = req.body;

  if (!referralCode) {
    return res.status(400).json({ message: "كود الإحالة مطلوب" });
  }

  try {
    const result = await withDataLock(async () => {
      const data = readData();
      const referrer = data.users.find(u => u.referralCode === referralCode);
      const referee = data.users.find(u => u.id === req.session.userId);

      if (!referrer) {
        throw new Error("كود الإحالة غير صحيح");
      }

      if (!referee) {
        throw new Error("المستخدم غير موجود");
      }

      if (referee.referredBy) {
        throw new Error("تم استخدام إحالة من قبل");
      }

      // Update referee
      referee.referredBy = referralCode;

      // Update referrer
      if (!referrer.referrals) {
        referrer.referrals = [];
      }

      referrer.referrals.push({
        userId: referee.id,
        email: referee.email,
        date: new Date().toISOString(),
        active: true,
        plan: referee.plan
      });

      writeDataSync(data);
      return { referrer, referee };
    });

    res.json({ 
      success: true,
      message: "تم تفعيل الإحالة بنجاح"
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.get('/api/depositAddress', (req, res) => {
  res.json({ 
    success: true, 
    address: config.TRC20_ADDRESS
  });
});

app.get('/api/balance', (req, res) => {
  res.json({
    success: true,
    balance: 0,
    availableBalance: 0
  });
});

app.get('/api/transactions', (req, res) => {
  res.json({
    success: true,
    deposits: [],
    withdrawals: []
  });
});

app.get('/api/networkInfo', (req, res) => {
  res.json({
    network: config.TRON_NETWORK,
    usdtContract: config.USDT_CONTRACT
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// System status endpoint for testing
app.get('/api/system-status', (req, res) => {
  const networkInfo = tronService.getNetworkInfo();
  res.json({
    walletInitialized: networkInfo.initialized,
    apiKeyConfigured: !!process.env.TRON_API_KEY,
    network: networkInfo.network,
    companyAddress: networkInfo.companyAddress
  });
});

// Company wallet info endpoint
app.get('/api/company-wallet-info', async (req, res) => {
  try {
    const result = await paymentService.getCompanyWalletBalance();
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'خطأ في جلب معلومات المحفظة'
    });
  }
});

// Test withdrawal endpoint
app.post('/api/test-withdrawal', async (req, res) => {
  const { address, amount } = req.body;
  
  if (!address || !amount) {
    return res.status(400).json({
      success: false,
      error: 'العنوان والمبلغ مطلوبان'
    });
  }
  
  try {
    const result = await tronService.sendUSDT(address, parseFloat(amount));
    
    if (result.success) {
      res.json({
        success: true,
        txid: result.txid,
        amount: result.amount,
        explorerLink: tronService.getExplorerLink(result.txid)
      });
    } else {
      res.status(500).json({
        success: false,
        error: result.error
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Error handling
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Initialize services
async function initializeServices() {
  try {
    // Initialize database
    await dbService.init();

    // Start payment monitoring
    await paymentService.startMonitoring();

    console.log('✅ All services initialized successfully');
  } catch (error) {
    console.error('❌ Failed to initialize services:', error);
  }
}

// Start server
server.listen(PORT, '0.0.0.0', async (err) => {
  if (err) {
    console.error('Server failed to start:', err);
    process.exit(1);
  }

  console.log(`✅ MERAC Server running at http://0.0.0.0:${PORT}`);
  console.log(`✅ Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`✅ Data file: ${DATA_FILE}`);

  // Initialize services after server starts
  await initializeServices();

  console.log('🚀 Server started successfully!');
});