const TronService = require('./tronService');
const tronService = new TronService();
const dbService = require('./databaseService');
const EventEmitter = require('events');
const config = require('../config');
const fs = require('fs');
const path = require('path');

class PaymentService extends EventEmitter {
  constructor() {
    super();
    this.monitoringInterval = null;
    this.lastCheckedTimestamp = Date.now();
    this.processedTransactions = new Set();
    this.minWithdrawal = config.MIN_WITHDRAWAL;
    this.withdrawalFee = config.WITHDRAWAL_FEE;
    this.companyAddress = config.TRC20_ADDRESS;
    
    // Load processed transactions from file
    this.loadProcessedTransactions();
  }

  // Load processed transactions from file
  loadProcessedTransactions() {
    try {
      const filePath = path.join(__dirname, '..', 'processed_txs.json');
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, 'utf-8');
        const txs = JSON.parse(data);
        this.processedTransactions = new Set(txs);
        console.log(`📋 Loaded ${this.processedTransactions.size} processed transactions`);
      }
    } catch (error) {
      console.error('Error loading processed transactions:', error);
    }
  }

  // Save processed transactions to file
  saveProcessedTransactions() {
    try {
      const filePath = path.join(__dirname, '..', 'processed_txs.json');
      const txs = Array.from(this.processedTransactions);
      fs.writeFileSync(filePath, JSON.stringify(txs, null, 2), 'utf-8');
    } catch (error) {
      console.error('Error saving processed transactions:', error);
    }
  }

  // Start monitoring for incoming payments to company wallet
  async startMonitoring() {
    console.log('🔍 Starting payment monitoring for company wallet:', this.companyAddress);
    
    // Initial check
    await this.checkIncomingPayments();

    // Check every 30 seconds
    this.monitoringInterval = setInterval(async () => {
      try {
        await this.checkIncomingPayments();
      } catch (error) {
        console.error('❌ Monitoring error:', error.message);
      }
    }, 30000); // 30 seconds

    console.log('✅ Payment monitoring started successfully');
  }

  // Stop monitoring
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      console.log('⏹️  Payment monitoring stopped');
    }
  }

  // Check for incoming payments to company wallet
  async checkIncomingPayments() {
    try {
      // Get recent incoming transactions
      const transactions = await tronService.getIncomingUSDTTransactions(this.companyAddress, 50);
      
      if (!transactions || transactions.length === 0) {
        return;
      }

      console.log(`📥 Found ${transactions.length} incoming transactions to check`);

      // Process each transaction
      for (const tx of transactions) {
        // Skip if already processed
        if (this.processedTransactions.has(tx.txid)) {
          continue;
        }

        // Skip old transactions (older than 24 hours)
        const txAge = Date.now() - tx.timestamp;
        if (txAge > 24 * 60 * 60 * 1000) {
          continue;
        }

        console.log(`💰 New payment detected: ${tx.amount} USDT from ${tx.from}`);
        console.log(`   Transaction ID: ${tx.txid}`);

        // Process the payment
        await this.processIncomingPayment(tx);
        
        // Mark as processed
        this.processedTransactions.add(tx.txid);
        this.saveProcessedTransactions();
      }
    } catch (error) {
      console.error('❌ Error checking incoming payments:', error.message);
    }
  }

  // Process incoming payment and activate subscription
  async processIncomingPayment(transaction) {
    try {
      const { txid, from, amount, timestamp } = transaction;

      // Try to find which plan this payment is for
      const matchedPlan = this.matchPaymentToPlan(amount);
      
      if (!matchedPlan) {
        console.log(`⚠️  Payment amount ${amount} USDT doesn't match any plan`);
        // Emit event for manual review
        this.emit('unmatchedPayment', {
          txid,
          from,
          amount,
          timestamp
        });
        return;
      }

      console.log(`✅ Payment matched to plan: ${matchedPlan.plan} (${matchedPlan.amount} USDT)`);

      // Find user by pending payment
      const user = await this.findUserByPendingPayment(amount, from);
      
      if (!user) {
        console.log(`⚠️  No user found with pending payment for ${amount} USDT`);
        // Emit event for manual review
        this.emit('orphanedPayment', {
          txid,
          from,
          amount,
          plan: matchedPlan.plan,
          timestamp
        });
        return;
      }

      // Activate subscription
      await this.activateSubscription(user.id, matchedPlan.plan, txid, amount);

      // Emit success event
      this.emit('paymentProcessed', {
        userId: user.id,
        email: user.email,
        plan: matchedPlan.plan,
        amount,
        txid,
        timestamp
      });

      console.log(`🎉 Subscription activated for user ${user.email}: ${matchedPlan.plan}`);
    } catch (error) {
      console.error('❌ Error processing incoming payment:', error.message);
    }
  }

  // Match payment amount to investment plan
  matchPaymentToPlan(amount) {
    const plans = config.INVESTMENT_PLANS;
    
    // Find exact or close match (within 0.5 USDT tolerance)
    for (const [planName, planData] of Object.entries(plans)) {
      const minInvestment = planData.minInvestment;
      if (Math.abs(amount - minInvestment) <= 0.5) {
        return {
          plan: planName,
          amount: minInvestment,
          dailyProfit: planData.daily
        };
      }
    }
    
    return null;
  }

  // Find user by pending payment
  async findUserByPendingPayment(amount, fromAddress) {
    try {
      // Read user data
      const dataFile = path.join(__dirname, '..', 'data.json');
      if (!fs.existsSync(dataFile)) {
        return null;
      }

      const data = JSON.parse(fs.readFileSync(dataFile, 'utf-8'));
      
      // Find user with pending payment for this amount
      const user = data.users.find(u => 
        u.pendingPayment && 
        Math.abs(u.pendingPayment.amount - amount) <= 0.5 &&
        u.pendingPayment.status === 'pending'
      );

      return user;
    } catch (error) {
      console.error('Error finding user by pending payment:', error.message);
      return null;
    }
  }

  // Activate subscription for user
  async activateSubscription(userId, plan, txid, amount) {
    try {
      const dataFile = path.join(__dirname, '..', 'data.json');
      const data = JSON.parse(fs.readFileSync(dataFile, 'utf-8'));
      
      const userIndex = data.users.findIndex(u => u.id === userId);
      if (userIndex === -1) {
        throw new Error('User not found');
      }

      // Update user plan
      data.users[userIndex].plan = plan;
      data.users[userIndex].subscribedAt = new Date().toISOString();
      data.users[userIndex].subscriptionTxid = txid;
      
      // Clear pending payment
      if (data.users[userIndex].pendingPayment) {
        data.users[userIndex].pendingPayment.status = 'completed';
        data.users[userIndex].pendingPayment.txid = txid;
        data.users[userIndex].pendingPayment.completedAt = new Date().toISOString();
      }

      // Save data
      fs.writeFileSync(dataFile, JSON.stringify(data, null, 2), 'utf-8');

      console.log(`✅ Subscription activated: User ${userId} -> ${plan}`);
      return true;
    } catch (error) {
      console.error('Error activating subscription:', error.message);
      return false;
    }
  }

  // Create pending payment for user
  async createPendingPayment(userId, plan, amount) {
    try {
      const dataFile = path.join(__dirname, '..', 'data.json');
      const data = JSON.parse(fs.readFileSync(dataFile, 'utf-8'));
      
      const userIndex = data.users.findIndex(u => u.id === userId);
      if (userIndex === -1) {
        throw new Error('User not found');
      }

      // Create pending payment
      data.users[userIndex].pendingPayment = {
        plan,
        amount,
        status: 'pending',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutes
      };

      // Save data
      fs.writeFileSync(dataFile, JSON.stringify(data, null, 2), 'utf-8');

      return {
        success: true,
        paymentAddress: this.companyAddress,
        amount,
        plan,
        expiresAt: data.users[userIndex].pendingPayment.expiresAt
      };
    } catch (error) {
      console.error('Error creating pending payment:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Process withdrawal request
  async processWithdrawal(userId, toAddress, amount) {
    try {
      // Validate address
      if (!tronService.isValidAddress(toAddress)) {
        return {
          success: false,
          error: 'عنوان المحفظة غير صحيح'
        };
      }

      // Check minimum withdrawal
      if (amount < this.minWithdrawal) {
        return {
          success: false,
          error: `الحد الأدنى للسحب هو ${this.minWithdrawal} USDT`
        };
      }

      // Calculate net amount after fee
      const netAmount = amount - this.withdrawalFee;

      if (netAmount <= 0) {
        return {
          success: false,
          error: 'المبلغ صغير جداً بعد خصم الرسوم'
        };
      }

      console.log(`💸 Processing withdrawal: ${amount} USDT to ${toAddress} for user ${userId}`);

      // Send USDT from company wallet
      const result = await tronService.sendUSDT(toAddress, netAmount);

      if (!result.success) {
        return {
          success: false,
          error: `فشل في إرسال الأموال: ${result.error}`
        };
      }

      // Record withdrawal in user data
      await this.recordWithdrawal(userId, toAddress, amount, netAmount, result.txid);

      console.log(`✅ Withdrawal successful! TXID: ${result.txid}`);

      return {
        success: true,
        txid: result.txid,
        amount: netAmount,
        fee: this.withdrawalFee,
        explorerLink: tronService.getExplorerLink(result.txid),
        message: 'تم إرسال الأموال بنجاح'
      };
    } catch (error) {
      console.error('❌ Error processing withdrawal:', error.message);
      return {
        success: false,
        error: 'حدث خطأ أثناء معالجة السحب'
      };
    }
  }

  // Record withdrawal in user data
  async recordWithdrawal(userId, toAddress, amount, netAmount, txid) {
    try {
      const dataFile = path.join(__dirname, '..', 'data.json');
      const data = JSON.parse(fs.readFileSync(dataFile, 'utf-8'));
      
      const userIndex = data.users.findIndex(u => u.id === userId);
      if (userIndex === -1) {
        throw new Error('User not found');
      }

      // Initialize withdrawal history if it doesn't exist
      if (!data.users[userIndex].withdrawalHistory) {
        data.users[userIndex].withdrawalHistory = [];
      }

      // Add withdrawal record
      data.users[userIndex].withdrawalHistory.push({
        id: txid,
        type: 'daily_profit',
        amount: netAmount,
        fee: this.withdrawalFee,
        grossAmount: amount,
        address: toAddress,
        status: 'completed',
        txid,
        createdAt: new Date().toISOString(),
        processedAt: new Date().toISOString(),
        explorerLink: tronService.getExplorerLink(txid)
      });

      // Update last withdrawal time
      data.users[userIndex].lastWithdrawalAt = new Date().toISOString();
      data.users[userIndex].dayCounter = (data.users[userIndex].dayCounter || 0) + 1;
      
      // Update TRC20 address
      data.users[userIndex].trc20 = toAddress;

      // Check referral gate
      if (data.users[userIndex].dayCounter === 2) {
        data.users[userIndex].pendingReferralGate = true;
      }

      // Save data
      fs.writeFileSync(dataFile, JSON.stringify(data, null, 2), 'utf-8');

      return true;
    } catch (error) {
      console.error('Error recording withdrawal:', error.message);
      return false;
    }
  }

  // Get company wallet balance
  async getCompanyWalletBalance() {
    try {
      const usdtBalance = await tronService.getUSDTBalance(this.companyAddress);
      const trxBalance = await tronService.getTRXBalance(this.companyAddress);

      return {
        success: true,
        address: this.companyAddress,
        usdtBalance,
        trxBalance,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting company wallet balance:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get payment info for plan
  getPaymentInfo(plan) {
    const planData = config.INVESTMENT_PLANS[plan];
    
    if (!planData) {
      return {
        success: false,
        error: 'خطة غير صالحة'
      };
    }

    return {
      success: true,
      plan,
      amount: planData.minInvestment,
      dailyProfit: planData.daily,
      paymentAddress: this.companyAddress,
      network: 'TRC20 (TRON)',
      currency: 'USDT'
    };
  }
}

module.exports = new PaymentService();
