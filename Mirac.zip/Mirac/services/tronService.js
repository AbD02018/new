const { TronWeb } = require('tronweb');
const config = require('../config');

class TronService {
  constructor() {
    this.network = config.TRON_NETWORK;
    this.usdtContract = config.USDT_CONTRACT;
    this.apiKey = config.TRON_API_KEY;
    this.companyAddress = config.TRC20_ADDRESS;
    
    // Initialize TronWeb
    const fullNode = this.network === 'mainnet' 
      ? 'https://api.trongrid.io'
      : 'https://api.shasta.trongrid.io';
    const solidityNode = fullNode;
    const eventServer = fullNode;
    
    this.tronWeb = new TronWeb({
      fullHost: fullNode,
      headers: { 
        'TRON-PRO-API-KEY': this.apiKey 
      }
    });

    // Set company wallet if private key is available
    if (process.env.COMPANY_WALLET_PRIVATE_KEY) {
      try {
        let privateKey = process.env.COMPANY_WALLET_PRIVATE_KEY.trim();
        
        // Remove '0x' prefix if present
        if (privateKey.startsWith('0x') || privateKey.startsWith('0X')) {
          privateKey = privateKey.substring(2);
        }
        
        // Validate private key format (should be 64 hex characters)
        if (!/^[0-9a-fA-F]{64}$/.test(privateKey)) {
          throw new Error('Private key must be 64 hexadecimal characters');
        }
        
        this.tronWeb.setPrivateKey(privateKey);
        
        // Get and log the derived address
        const derivedAddress = this.tronWeb.address.fromPrivateKey(privateKey);
        console.log('✅ Company wallet initialized successfully');
        console.log(`📍 Company wallet address: ${derivedAddress}`);
        
        // Verify it matches the configured address
        if (this.companyAddress && derivedAddress !== this.companyAddress) {
          console.warn(`⚠️  WARNING: Derived address (${derivedAddress}) differs from configured address (${this.companyAddress})`);
          console.warn('⚠️  Using derived address from private key');
          this.companyAddress = derivedAddress;
        }
      } catch (error) {
        console.error('❌ Failed to initialize company wallet:', error.message);
        console.error('❌ Please check that COMPANY_WALLET_PRIVATE_KEY is a valid 64-character hex string');
      }
    } else {
      console.warn('⚠️  COMPANY_WALLET_PRIVATE_KEY not set - withdrawals will not work');
    }
  }

  // Validate TRON address
  isValidAddress(address) {
    if (!address || typeof address !== 'string') return false;
    return this.tronWeb.isAddress(address);
  }

  // Get USDT balance for address (in USDT, not SUN)
  async getUSDTBalance(address) {
    try {
      if (!this.isValidAddress(address)) {
        throw new Error('Invalid TRON address');
      }

      const contract = await this.tronWeb.contract().at(this.usdtContract);
      const balance = await contract.balanceOf(address).call();
      
      // Convert from smallest unit (6 decimals for USDT) to USDT
      const usdtBalance = parseFloat(this.tronWeb.fromSun(balance)) / 1;
      
      return usdtBalance;
    } catch (error) {
      console.error('Error getting USDT balance:', error.message);
      return 0;
    }
  }

  // Get TRX balance for address
  async getTRXBalance(address) {
    try {
      if (!this.isValidAddress(address)) {
        throw new Error('Invalid TRON address');
      }

      const balance = await this.tronWeb.trx.getBalance(address);
      return this.tronWeb.fromSun(balance);
    } catch (error) {
      console.error('Error getting TRX balance:', error.message);
      return 0;
    }
  }

  // Get account info
  async getAccountInfo(address) {
    try {
      if (!this.isValidAddress(address)) {
        throw new Error('Invalid TRON address');
      }

      const account = await this.tronWeb.trx.getAccount(address);
      const trxBalance = await this.getTRXBalance(address);
      const usdtBalance = await this.getUSDTBalance(address);

      return {
        success: true,
        address,
        trxBalance,
        usdtBalance,
        account
      };
    } catch (error) {
      console.error('Error getting account info:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get transactions for an address (incoming USDT transfers to company wallet)
  async getIncomingUSDTTransactions(address, limit = 50) {
    try {
      if (!this.isValidAddress(address)) {
        throw new Error('Invalid TRON address');
      }

      // Use TronGrid API to get TRC20 transfers
      const url = `${this.tronWeb.fullNode.host}/v1/accounts/${address}/transactions/trc20?limit=${limit}&contract_address=${this.usdtContract}`;
      
      const response = await fetch(url, {
        headers: {
          'TRON-PRO-API-KEY': this.apiKey
        }
      });

      if (!response.ok) {
        throw new Error(`TronGrid API error: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data.data) {
        return [];
      }

      // Filter for incoming transactions only (to this address)
      const incomingTxs = data.data.filter(tx => 
        tx.to && tx.to.toLowerCase() === address.toLowerCase()
      );

      return incomingTxs.map(tx => ({
        txid: tx.transaction_id,
        from: tx.from,
        to: tx.to,
        amount: parseFloat(tx.value) / 1000000, // Convert from smallest unit (6 decimals)
        timestamp: tx.block_timestamp,
        confirmed: true
      }));
    } catch (error) {
      console.error('Error getting incoming transactions:', error.message);
      return [];
    }
  }

  // Get transaction details
  async getTransactionInfo(txid) {
    try {
      if (!txid || typeof txid !== 'string') {
        throw new Error('Invalid transaction ID');
      }

      const txInfo = await this.tronWeb.trx.getTransaction(txid);
      
      if (!txInfo) {
        return {
          success: false,
          error: 'Transaction not found'
        };
      }

      const txReceipt = await this.tronWeb.trx.getTransactionInfo(txid);

      return {
        success: true,
        txid,
        transaction: txInfo,
        receipt: txReceipt,
        confirmed: txReceipt.blockNumber ? true : false,
        timestamp: txInfo.raw_data?.timestamp || Date.now()
      };
    } catch (error) {
      console.error('Error getting transaction info:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Send USDT from company wallet to user
  async sendUSDT(toAddress, amount) {
    try {
      // Validate inputs
      if (!this.isValidAddress(toAddress)) {
        throw new Error('Invalid recipient TRON address');
      }

      if (amount <= 0) {
        throw new Error('Amount must be greater than 0');
      }

      // Check if company wallet is initialized
      if (!process.env.COMPANY_WALLET_PRIVATE_KEY) {
        throw new Error('Company wallet private key not configured');
      }

      // Check company wallet balance
      const companyBalance = await this.getUSDTBalance(this.companyAddress);
      if (companyBalance < amount) {
        throw new Error(`Insufficient company wallet balance. Available: ${companyBalance} USDT, Required: ${amount} USDT`);
      }

      // Check TRX balance for fees
      const trxBalance = await this.getTRXBalance(this.companyAddress);
      if (trxBalance < 20) {
        console.warn(`⚠️  Low TRX balance: ${trxBalance} TRX. Minimum 20 TRX recommended for fees.`);
      }

      console.log(`💸 Sending ${amount} USDT from company wallet to ${toAddress}...`);

      // Get USDT contract instance
      const contract = await this.tronWeb.contract().at(this.usdtContract);
      
      // Convert amount to smallest unit (6 decimals for USDT)
      const amountInSmallestUnit = Math.floor(amount * 1000000);

      // Send USDT
      const transaction = await contract.transfer(
        toAddress,
        amountInSmallestUnit
      ).send({
        feeLimit: 100000000, // 100 TRX fee limit
        callValue: 0,
        shouldPollResponse: true
      });

      console.log(`✅ USDT sent successfully! Transaction ID: ${transaction}`);

      return {
        success: true,
        txid: transaction,
        amount,
        from: this.companyAddress,
        to: toAddress,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('❌ Error sending USDT:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Verify payment (check if a specific transaction is valid)
  async verifyPayment(txid, expectedAmount, expectedRecipient) {
    try {
      const txInfo = await this.getTransactionInfo(txid);
      
      if (!txInfo.success) {
        return {
          valid: false,
          error: 'Transaction not found'
        };
      }

      // Parse transaction details
      const contract = txInfo.transaction.raw_data.contract[0];
      
      if (contract.type !== 'TriggerSmartContract') {
        return {
          valid: false,
          error: 'Not a TRC20 transfer transaction'
        };
      }

      // Decode the transfer data
      const parameter = contract.parameter.value;
      const data = parameter.data;
      
      // Check if it's a transfer to the expected address
      // This is a simplified check - in production you'd parse the contract call data
      
      return {
        valid: true,
        txid,
        confirmed: txInfo.confirmed,
        timestamp: txInfo.timestamp
      };
    } catch (error) {
      console.error('Error verifying payment:', error.message);
      return {
        valid: false,
        error: error.message
      };
    }
  }

  // Get network info
  getNetworkInfo() {
    return {
      network: this.network,
      usdtContract: this.usdtContract,
      companyAddress: this.companyAddress,
      explorer: this.network === 'mainnet' 
        ? 'https://tronscan.org' 
        : 'https://shasta.tronscan.org',
      minConfirmations: 19,
      initialized: !!process.env.COMPANY_WALLET_PRIVATE_KEY
    };
  }

  // Format address for display (first 8 + last 6 characters)
  formatAddress(address) {
    if (!address || address.length < 20) return address;
    return `${address.substring(0, 8)}...${address.substring(address.length - 6)}`;
  }

  // Get explorer link for transaction
  getExplorerLink(txid) {
    const baseUrl = this.network === 'mainnet'
      ? 'https://tronscan.org/#/transaction/'
      : 'https://shasta.tronscan.org/#/transaction/';
    return `${baseUrl}${txid}`;
  }
}

module.exports = TronService;
