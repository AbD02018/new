const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const config = require('../config');

class DatabaseService {
  constructor() {
    this.dbPath = path.join(__dirname, '..', 'database.sqlite');
    this.db = null;
    this.init();
  }

  // Initialize the database connection and create tables if they don't exist
  async init() {
    try {
      this.db = new sqlite3.Database(this.dbPath);

      // Create tables if they don't exist
      await this.createTables();

      console.log('Database connected successfully');
    } catch (error) {
      console.error('Database connection error:', error);
    }
  }

  // Create necessary database tables
  async createTables() {
    return new Promise((resolve, reject) => {
      const tables = [
        `CREATE TABLE IF NOT EXISTS user_addresses (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT NOT NULL UNIQUE,
          address TEXT NOT NULL,
          encrypted_private_key TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS user_balances (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT NOT NULL UNIQUE,
          balance REAL DEFAULT 0,
          locked_balance REAL DEFAULT 0,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS deposits (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT NOT NULL,
          address TEXT NOT NULL,
          txid TEXT NOT NULL UNIQUE,
          amount REAL NOT NULL,
          status TEXT DEFAULT 'pending',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          confirmed_at DATETIME
        )`,
        `CREATE TABLE IF NOT EXISTS withdrawals (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          to_address TEXT NOT NULL,
          amount REAL NOT NULL,
          net_amount REAL NOT NULL,
          fee REAL NOT NULL,
          status TEXT DEFAULT 'pending',
          txid TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          processed_at DATETIME
        )`
      ];

      let completed = 0;
      tables.forEach(sql => {
        this.db.run(sql, (err) => {
          if (err) {
            console.error('Error creating table:', err);
            reject(err);
          } else {
            completed++;
            if (completed === tables.length) {
              resolve();
            }
          }
        });
      });
    });
  }

  // Get user address
  async getUserAddress(userId) {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM user_addresses WHERE user_id = ?',
        [userId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  }

  // Save user address
  async saveUserAddress(userId, address, privateKey) {
    return new Promise((resolve, reject) => {
      this.db.run(
        'INSERT OR REPLACE INTO user_addresses (user_id, address, encrypted_private_key) VALUES (?, ?, ?)',
        [userId, address, privateKey],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }

  // Get all user addresses
  async getAllUserAddresses() {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT user_id, address FROM user_addresses',
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows || []);
        }
      );
    });
  }

  // Get user balance
  async getUserBalance(userId) {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM user_balances WHERE user_id = ?',
        [userId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row || { user_id: userId, balance: 0, locked_balance: 0 });
        }
      );
    });
  }

  // Get user deposits
  async getUserDeposits(userId, limit = 50) {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
        [userId, limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows || []);
        }
      );
    });
  }

  // Get user withdrawals
  async getUserWithdrawals(userId, limit = 50) {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
        [userId, limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows || []);
        }
      );
    });
  }

  // Add user
  async addUser(userData) {
    return new Promise((resolve, reject) => {
      this.db.run(
        'INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)',
        [userData.name, userData.email, userData.passwordHash, new Date().toISOString()],
        function(err) {
          if (err) reject(err);
          else resolve({ id: this.lastID, ...userData, createdAt: new Date().toISOString() });
        }
      );
    });
  }

  // Get user by ID
  async getUserById(userId) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM users WHERE id = ?', [userId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  // Get user by email
  async getUserByEmail(email) {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  // Update user
  async updateUser(userId, updates) {
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = fields.map(field => `${field} = ?`).join(', ');

    return new Promise((resolve, reject) => {
      this.db.run(
        `UPDATE users SET ${setClause}, updated_at = ? WHERE id = ?`,
        [...values, new Date().toISOString(), userId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  }

  // Record deposit
  async recordDeposit(userId, address, txid, amount) {
    return new Promise((resolve, reject) => {
      this.db.run(
        'INSERT INTO deposits (user_id, address, txid, amount, status) VALUES (?, ?, ?, ?, ?)',
        [userId, address, txid, amount, 'pending'],
        function(err) {
          if (err) reject(err);
          else resolve({ id: this.lastID, userId, address, txid, amount, status: 'pending', createdAt: new Date().toISOString() });
        }
      );
    });
  }

  // Record withdrawal
  async recordWithdrawal(userId, toAddress, amount, fee, netAmount) {
    return new Promise((resolve, reject) => {
      this.db.run(
        'INSERT INTO withdrawals (id, user_id, to_address, amount, net_amount, fee, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [`WD_${Date.now()}_${userId}`, userId, toAddress, amount, netAmount, fee, 'pending'],
        function(err) {
          if (err) reject(err);
          else resolve({ id: `WD_${Date.now()}_${userId}`, userId, toAddress, amount, netAmount, fee, status: 'pending', createdAt: new Date().toISOString() });
        }
      );
    });
  }

  // Update user balance
  async updateUserBalance(userId, balance, lockedBalance = null) {
    let updateQuery = 'UPDATE user_balances SET balance = ?, updated_at = ?';
    const queryParams = [balance, new Date().toISOString()];

    if (lockedBalance !== null) {
      updateQuery += ', locked_balance = ?';
      queryParams.push(lockedBalance);
    }

    updateQuery += ' WHERE user_id = ?';
    queryParams.push(userId);

    return new Promise((resolve, reject) => {
      this.db.run(updateQuery, queryParams, function(err) {
        if (err) reject(err);
        else resolve(this.changes);
      });
    });
  }

  // Update deposit status
  async updateDepositStatus(depositId, status, txid = null) {
    let updateQuery = 'UPDATE deposits SET status = ?, updated_at = ?';
    const queryParams = [status, new Date().toISOString()];

    if (txid) {
      updateQuery += ', txid = ?, confirmed_at = ?';
      queryParams.push(txid, new Date().toISOString());
    }

    updateQuery += ' WHERE id = ?';
    queryParams.push(depositId);

    return new Promise((resolve, reject) => {
      this.db.run(updateQuery, queryParams, function(err) {
        if (err) reject(err);
        else resolve(this.changes);
      });
    });
  }

  // Update withdrawal status
  async updateWithdrawalStatus(withdrawalId, status, txid = null) {
    let updateQuery = 'UPDATE withdrawals SET status = ?, updated_at = ?';
    const queryParams = [status, new Date().toISOString()];

    if (txid) {
      updateQuery += ', txid = ?, processed_at = ?';
      queryParams.push(txid, new Date().toISOString());
    }

    updateQuery += ' WHERE id = ?';
    queryParams.push(withdrawalId);

    return new Promise((resolve, reject) => {
      this.db.run(updateQuery, queryParams, function(err) {
        if (err) reject(err);
        else resolve(this.changes);
      });
    });
  }

  // Get statistics
  async getStats() {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT COUNT(*) as totalUsers FROM users', (err, userCount) => {
        if (err) return reject(err);
        this.db.get('SELECT COUNT(*) as totalDeposits FROM deposits', (err, depositCount) => {
          if (err) return reject(err);
          this.db.get('SELECT COUNT(*) as totalWithdrawals FROM withdrawals', (err, withdrawalCount) => {
            if (err) return reject(err);
            this.db.get('SELECT SUM(amount) as totalDepositAmount FROM deposits', (err, totalDepositAmount) => {
              if (err) return reject(err);
              this.db.get('SELECT SUM(amount) as totalWithdrawalAmount FROM withdrawals', (err, totalWithdrawalAmount) => {
                if (err) return reject(err);

                resolve({
                  totalUsers: userCount.totalUsers,
                  totalDeposits: depositCount.totalDeposits,
                  totalWithdrawals: withdrawalCount.totalWithdrawals,
                  totalDepositAmount: totalDepositAmount.totalDepositAmount || 0,
                  totalWithdrawalAmount: totalWithdrawalAmount.totalWithdrawalAmount || 0
                });
              });
            });
          });
        });
      });
    });
  }

  // Close the database connection
  close() {
    if (this.db) {
      this.db.close((err) => {
        if (err) {
          console.error('Error closing database:', err.message);
        } else {
          console.log('Database connection closed');
        }
      });
    }
  }
}

module.exports = new DatabaseService();