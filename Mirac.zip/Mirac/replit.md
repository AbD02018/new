# MERAC

## Overview

MERAC is a financial investment platform built with a Node.js backend and vanilla HTML/CSS/JavaScript frontend. The application provides user registration, investment tracking, referral systems, news feeds, team management, and reporting capabilities. It features a modern glassmorphic UI design with Arabic language support and uses file-based JSON storage for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 24, 2025)

- **Replit Environment Setup**: Successfully imported from GitHub and configured for Replit
- **Dependencies Installed**: All npm packages installed (express, bcrypt, cors, socket.io, tronweb, etc.)
- **Workflow Configured**: Server workflow running on port 5000
- **Server Status**: Running successfully at http://0.0.0.0:5000
- **Frontend Status**: Login/signup page loading correctly
- **Data Storage**: Initialized data.json file for user data persistence

## System Architecture

### Frontend Architecture
- **Technology Stack**: Vanilla HTML, CSS, and JavaScript with no frontend frameworks
- **UI Design**: Glassmorphic design system with CSS custom properties for theming
- **Multi-language Support**: Supports both English (LTR) and Arabic (RTL) layouts
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox
- **Icon System**: Lucide icons for consistent iconography
- **Charting**: Chart.js integration for data visualization and reports

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **API Design**: RESTful API structure with JSON responses
- **Middleware Stack**: CORS enabled, JSON body parsing, static file serving
- **Error Handling**: Basic error responses with HTTP status codes
- **File Structure**: Modular organization with separate public assets

### Data Storage
- **Primary Storage**: File-based JSON storage (`data.json`)
- **Data Operations**: Synchronous file read/write operations
- **Schema**: Simple user objects with fields for authentication, profile data, and referral tracking
- **Backup Strategy**: No automated backup system currently implemented

### Authentication & Authorization
- **Authentication Method**: Password-based authentication with bcrypt hashing
- **Session Management**: Express-session middleware for session management
- **Password Security**: Bcrypt password hashing with 10 salt rounds
- **User Registration**: Email uniqueness validation and security questions for password recovery

### Application Features
- **User Management**: Registration, login, and profile management
- **Investment Tracking**: Investment plans and portfolio management
- **Referral System**: User referral tracking with referral codes
- **News System**: Financial news and updates display
- **Reporting**: Charts and analytics for user data
- **Support System**: Help desk and customer support features
- **Team Management**: Team structure and hierarchy management

### Security Considerations
- **Data Validation**: Input validation on registration and authentication
- **CORS Policy**: Enabled for cross-origin requests
- **Password Storage**: Bcrypt hashing implemented for secure password storage
- **Session Management**: Secure session cookies with configurable expiration
- **Environment Variables**: Sensitive data managed via Replit secrets

## External Dependencies

### NPM Packages
- **express**: Web framework for Node.js
- **cors**: Cross-Origin Resource Sharing middleware
- **bcrypt**: Password hashing and security
- **express-session**: Session management middleware
- **socket.io**: Real-time bidirectional communication
- **tronweb**: TRON blockchain integration
- **drizzle-orm**: Database ORM for SQLite
- **sqlite3**: SQLite database driver
- **axios**: HTTP client for API requests
- **dotenv**: Environment variable management
- **node-cron**: Task scheduling
- **fs**: File system operations (Node.js built-in)
- **path**: File path utilities (Node.js built-in)

### Frontend Libraries
- **Lucide Icons**: Icon library loaded via CDN
- **Chart.js**: Charting library for data visualization
- **Google Fonts**: Poppins font family for typography

### Development Environment
- **Runtime**: Node.js 20 on Replit
- **Port Configuration**: 5000 (bound to 0.0.0.0)
- **Static Assets**: Served from public directory
- **File Storage**: Local file system for data persistence (data.json)
- **Environment Variables**: Managed via Replit secrets (COMPANY_WALLET_PRIVATE_KEY, TRON_API_KEY)

### Browser Requirements
- **Modern Browser Support**: ES6+ JavaScript features
- **CSS Features**: CSS Grid, Flexbox, CSS Custom Properties
- **RTL Support**: Right-to-left text direction for Arabic content
- **Responsive Design**: Mobile and desktop viewport support