
document.addEventListener('DOMContentLoaded', function() {
  // Initialize navigation system
  initializeNavigation();
  
  // Initialize page-specific features
  initializePageFeatures();
  
  // Initialize Lucide icons
  if (window.lucide) {
    lucide.createIcons();
  }
});

function initializeNavigation() {
  // Handle all navigation buttons with data-navigate attribute
  document.addEventListener('click', function(e) {
    // Navigation buttons
    const navigateBtn = e.target.closest('[data-navigate]');
    if (navigateBtn) {
      e.preventDefault();
      e.stopPropagation();
      const targetPage = navigateBtn.getAttribute('data-navigate');
      if (targetPage) {
        navigateToPage(targetPage);
      }
      return;
    }
    
    // Back buttons
    if (e.target.closest('.back-btn') || e.target.closest('[onclick*="history.back"]')) {
      e.preventDefault();
      history.back();
      return;
    }
    
    // Home buttons
    if (e.target.closest('#homeBtn') || e.target.closest('.home-btn')) {
      e.preventDefault();
      navigateToPage('profile.html');
      return;
    }

    // Auth page specific buttons
    const targetElement = e.target;
    const targetId = targetElement.id;
    const closestWithId = targetElement.closest('[id]');
    const closestId = closestWithId ? closestWithId.id : null;

    // Tab switching buttons
    if (targetId === 'tabLogin' || closestId === 'tabLogin') {
      e.preventDefault();
      e.stopPropagation();
      switchToTab('login');
      return;
    }

    if (targetId === 'tabSignup' || closestId === 'tabSignup') {
      e.preventDefault();
      e.stopPropagation();
      switchToTab('signup');
      return;
    }

    if (targetId === 'toLogin' || closestId === 'toLogin') {
      e.preventDefault();
      e.stopPropagation();
      switchToTab('login');
      return;
    }

    // Modal buttons
    if (targetId === 'openTerms' || closestId === 'openTerms') {
      e.preventDefault();
      openTermsModal();
      return;
    }

    if (targetId === 'footerTermsInline' || closestId === 'footerTermsInline') {
      e.preventDefault();
      openTermsModal();
      return;
    }

    if (targetId === 'termsLinkInline' || closestId === 'termsLinkInline') {
      e.preventDefault();
      openTermsModal();
      return;
    }

    if (targetId === 'closeTerms' || closestId === 'closeTerms') {
      e.preventDefault();
      closeTermsModal();
      return;
    }

    // Forgot password buttons
    if (targetId === 'openForgot' || closestId === 'openForgot') {
      e.preventDefault();
      openForgotPasswordModal();
      return;
    }

    if (targetId === 'closeForgot' || closestId === 'closeForgot') {
      e.preventDefault();
      closeForgotPasswordModal();
      return;
    }

    if (targetId === 'backToLogin' || closestId === 'backToLogin') {
      e.preventDefault();
      closeForgotPasswordModal();
      return;
    }

    // Country selector buttons
    if (targetId === 'openCountry' || closestId === 'openCountry') {
      e.preventDefault();
      openCountrySelector();
      return;
    }

    if (targetId === 'closeCountry' || closestId === 'closeCountry') {
      e.preventDefault();
      closeCountrySelector();
      return;
    }

    // Form submit buttons
    if (targetId === 'doLogin' || closestId === 'doLogin') {
      e.preventDefault();
      if (typeof handleLoginClick === 'function') {
        handleLoginClick();
      }
      return;
    }

    if (targetId === 'doSignup' || closestId === 'doSignup') {
      e.preventDefault();
      if (typeof handleSignupClick === 'function') {
        handleSignupClick();
      }
      return;
    }

    // Security questions buttons
    if (targetId === 'useSecurityQuestions' || closestId === 'useSecurityQuestions') {
      e.preventDefault();
      if (typeof handleSecurityQuestionsClick === 'function') {
        handleSecurityQuestionsClick();
      }
      return;
    }

    if (targetId === 'resetWithSecurity' || closestId === 'resetWithSecurity') {
      e.preventDefault();
      if (typeof handleResetPasswordClick === 'function') {
        handleResetPasswordClick();
      }
      return;
    }

    // Language toggle
    if (targetId === 'langToggle' || closestId === 'langToggle') {
      e.preventDefault();
      toggleLanguage();
      return;
    }

    // Password toggle buttons
    if (targetId === 'loginTogglePass' || closestId === 'loginTogglePass') {
      e.preventDefault();
      togglePasswordVisibility('loginPassword', targetElement);
      return;
    }

    if (targetId === 'regTogglePass' || closestId === 'regTogglePass') {
      e.preventDefault();
      togglePasswordVisibility('regPassword', targetElement);
      return;
    }
  });
  
  // Handle browser back/forward
  window.addEventListener('popstate', function(e) {
    if (e.state && e.state.page) {
      loadPageContent(e.state.page);
    }
  });
}

function navigateToPage(page) {
  // Update URL
  const url = new URL(window.location);
  url.pathname = '/' + page;
  history.pushState({ page: page }, '', url);
  
  // Navigate to page
  window.location.href = page;
}

function switchToTab(tabType) {
  const tabLogin = document.getElementById('tabLogin');
  const tabSignup = document.getElementById('tabSignup');
  const panelLogin = document.getElementById('panelLogin');
  const panelSignup = document.getElementById('panelSignup');

  if (!tabLogin || !tabSignup || !panelLogin || !panelSignup) {
    return; // Elements not found
  }

  if (tabType === 'login') {
    tabLogin.classList.add('active');
    tabLogin.setAttribute('aria-selected', 'true');
    tabSignup.classList.remove('active');
    tabSignup.setAttribute('aria-selected', 'false');
    panelLogin.classList.remove('hidden');
    panelSignup.classList.add('hidden');
  } else if (tabType === 'signup') {
    tabSignup.classList.add('active');
    tabSignup.setAttribute('aria-selected', 'true');
    tabLogin.classList.remove('active');
    tabLogin.setAttribute('aria-selected', 'false');
    panelSignup.classList.remove('hidden');
    panelLogin.classList.add('hidden');
  }
}

function togglePasswordVisibility(inputId, button) {
  const input = document.getElementById(inputId);
  const icon = button.querySelector('i');
  
  if (!input || !icon) return;
  
  if (input.type === 'password') {
    input.type = 'text';
    icon.setAttribute('data-lucide', 'eye-off');
  } else {
    input.type = 'password';
    icon.setAttribute('data-lucide', 'eye');
  }
  
  if (window.lucide) {
    lucide.createIcons();
  }
}

function initializePageFeatures() {
  const currentPage = getCurrentPage();
  
  switch (currentPage) {
    case 'index.html':
      initializeAuthPage();
      break;
    case 'profile.html':
      initializeProfilePage();
      break;
    case 'payment.html':
      initializePaymentPage();
      break;
    case 'plan.html':
      initializePlanPage();
      break;
    default:
      initializeDefaultPage();
  }
}

function getCurrentPage() {
  const path = window.location.pathname;
  return path === '/' ? 'index.html' : path.split('/').pop() || 'index.html';
}

function initializeAuthPage() {
  // Initialize form handlers if they exist
  if (typeof handleSignupSubmit === 'function') {
    handleSignupSubmit();
  }
  if (typeof handleLoginSubmit === 'function') {
    handleLoginSubmit();
  }
}

function initializeProfilePage() {
  // Load user data
  if (typeof loadUserProfile === 'function') {
    loadUserProfile();
  }
  
  // Initialize profile buttons
  initializeProfileButtons();
}

function initializePaymentPage() {
  // Initialize payment system
  if (typeof initializePayment === 'function') {
    initializePayment();
  }
}

function initializePlanPage() {
  // Initialize plan selection
  if (typeof loadPlans === 'function') {
    loadPlans();
  }
}

function initializeDefaultPage() {
  console.log('Default page initialization for:', getCurrentPage());
}

// Language toggle function
function toggleLanguage() {
  const currentLang = document.documentElement.lang || 'en';
  const newLang = currentLang === 'en' ? 'ar' : 'en';
  
  document.documentElement.lang = newLang;
  document.body.dir = newLang === 'ar' ? 'rtl' : 'ltr';
  
  const langLabel = document.getElementById('langLabel');
  if (langLabel) {
    langLabel.textContent = newLang === 'ar' ? 'English' : 'عربي';
  }
  
  localStorage.setItem('preferred-language', newLang);
  
  // Update UI if function exists
  if (typeof updateLangUI === 'function') {
    updateLangUI();
  }
}

// Terms modal functions
function openTermsModal() {
  const modal = document.getElementById('termsBackdrop');
  if (modal) {
    modal.classList.add('show');
  }
}

function closeTermsModal() {
  const modal = document.getElementById('termsBackdrop');
  if (modal) {
    modal.classList.remove('show');
  }
}

// Forgot password modal functions
function openForgotPasswordModal() {
  const modal = document.getElementById('forgotBackdrop');
  if (modal) {
    modal.classList.add('show');
    // Reset form
    const emailField = document.getElementById('forgotEmail');
    const securityStep = document.getElementById('securityQuestionsStep');
    const useSecurityBtn = document.getElementById('useSecurityQuestions');
    
    if (emailField) emailField.value = '';
    if (securityStep) securityStep.style.display = 'none';
    if (useSecurityBtn) useSecurityBtn.style.display = 'block';
    
    // Clear security answers
    ['securityAnswer1', 'securityAnswer2', 'securityAnswer3', 'newPasswordSecurity', 'confirmPasswordSecurity'].forEach(id => {
      const field = document.getElementById(id);
      if (field) field.value = '';
    });
  }
}

function closeForgotPasswordModal() {
  const modal = document.getElementById('forgotBackdrop');
  if (modal) {
    modal.classList.remove('show');
  }
}

// Country selector functions
function openCountrySelector() {
  const modal = document.getElementById('countryBackdrop');
  if (modal) {
    modal.classList.add('show');
    if (typeof renderCountryList === 'function') {
      renderCountryList();
    }
    const searchField = document.getElementById('countrySearch');
    if (searchField) {
      setTimeout(() => searchField.focus(), 100);
    }
  }
}

function closeCountrySelector() {
  const modal = document.getElementById('countryBackdrop');
  if (modal) {
    modal.classList.remove('show');
  }
}

// Profile functions
async function loadUserProfile() {
  try {
    const response = await fetch('/api/me');
    if (response.ok) {
      const userData = await response.json();
      updateProfileUI(userData);
    }
  } catch (error) {
    console.error('Error loading profile:', error);
  }
}

function updateProfileUI(userData) {
  // Update profile elements
  const elements = {
    'userEmail': userData.email,
    'userPlan': userData.plan,
    'userBalance': userData.balance || 0,
    'dayCounter': userData.dayCounter || 0,
    'referralCode': userData.referralCode
  };
  
  Object.entries(elements).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  });
}

function initializeProfileButtons() {
  // Investment buttons
  const investButtons = document.querySelectorAll('.invest-btn, [data-plan]');
  investButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const plan = this.getAttribute('data-plan') || this.closest('[data-plan]')?.getAttribute('data-plan');
      if (plan) {
        selectInvestmentPlan(plan);
      }
    });
  });
  
  // Withdrawal buttons
  const withdrawButtons = document.querySelectorAll('.withdraw-btn');
  withdrawButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      navigateToPage('withdraw.html');
    });
  });
}

function selectInvestmentPlan(planName) {
  // Store selected plan
  sessionStorage.setItem('selectedPlan', JSON.stringify({
    name: planName,
    investment: getPlanInvestment(planName)
  }));
  
  // Navigate to payment
  navigateToPage('payment.html');
}

function getPlanInvestment(planName) {
  const plans = {
    'VIP_1': 1,
    'VIP_2': 2.5,
    'VIP_3': 4,
    'VIP_4': 8,
    'VIP_5': 10,
    'VIP_6': 15,
    'VIP_7': 25,
    'VIP_8': 35,
    'VIP_9': 60,
    'VIP_10': 85,
    'VIP_11': 100,
    'VIP_Bronze': 200,
    'VIP_Silver': 400,
    'VIP_Golden': 700,
    'VIP_Diamond': 1000
  };
  
  return plans[planName] || 0;
}

// Utility functions
function showToast(message, type = 'info') {
  // Remove existing toasts
  const existingToasts = document.querySelectorAll('.toast');
  existingToasts.forEach(toast => toast.remove());
  
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    padding: 12px 20px;
    border-radius: 8px;
    color: white;
    background: ${type === 'success' ? '#22c55e' : type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : '#3b82f6'};
    animation: slideIn 0.3s ease-out;
    font-family: 'Poppins', sans-serif;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    max-width: 300px;
    word-wrap: break-word;
  `;
  toast.textContent = message;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    if (toast && toast.parentNode) {
      toast.remove();
    }
  }, 4000);
}

// Add CSS for animations if not exists
if (!document.getElementById('navigationStyles')) {
  const style = document.createElement('style');
  style.id = 'navigationStyles';
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    .toast {
      animation: slideIn 0.3s ease-out;
    }
    
    .button-loading {
      opacity: 0.7;
      pointer-events: none;
    }
    
    .button-loading::after {
      content: '';
      width: 16px;
      height: 16px;
      margin-left: 8px;
      border: 2px solid #ffffff;
      border-top: 2px solid transparent;
      border-radius: 50%;
      display: inline-block;
      animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);
}

// Make functions globally available
window.navigateToPage = navigateToPage;
window.switchToTab = switchToTab;
window.toggleLanguage = toggleLanguage;
window.openTermsModal = openTermsModal;
window.closeTermsModal = closeTermsModal;
window.openForgotPasswordModal = openForgotPasswordModal;
window.closeForgotPasswordModal = closeForgotPasswordModal;
window.openCountrySelector = openCountrySelector;
window.closeCountrySelector = closeCountrySelector;
window.showToast = showToast;

// Initialize navigation on script load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeNavigation);
} else {
  initializeNavigation();
}
