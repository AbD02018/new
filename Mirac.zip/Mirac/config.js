module.exports = {
  // Server Configuration
  PORT: process.env.PORT || 5000,
  HOST: '0.0.0.0',

  // Session Configuration
  SESSION_SECRET: process.env.SESSION_SECRET || 'merac-session-secret-key-2024-secure-advanced-protection',

  // TRON Network Configuration
  TRON_NETWORK: process.env.TRON_NETWORK || 'mainnet',
  TRC20_ADDRESS: process.env.COMPANY_TRC20_ADDRESS || 'TTgV8kcBLBnkdFz3EHHXnvJrDHCNhTKsyt',
  USDT_CONTRACT: process.env.USDT_CONTRACT_ADDRESS || 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
  TRON_API_KEY: process.env.TRON_API_KEY || '',

  // Database Configuration
  DATABASE_PATH: process.env.DATABASE_PATH || './database.sqlite',
  DATA_FILE_PATH: './data.json',

  // Payment Configuration
  MIN_WITHDRAWAL: parseInt(process.env.MIN_WITHDRAWAL) || 10,
  WITHDRAWAL_FEE: parseFloat(process.env.WITHDRAWAL_FEE) || 1.0,

  // Email Configuration
  EMAIL_USER: process.env.EMAIL_USER || 'noreply@merac.com',
  EMAIL_PASSWORD: process.env.EMAIL_PASSWORD || 'app-password-here',

  // Security
  BCRYPT_ROUNDS: 12,

  // Rate Limiting
  RATE_LIMIT_WINDOW: 15 * 60 * 1000, // 15 minutes
  RATE_LIMIT_MAX: 100, // 100 requests per window

  // Development
  DEBUG: process.env.DEBUG === 'true' || false,
  NODE_ENV: process.env.NODE_ENV || 'production',

  // Investment Plans
  INVESTMENT_PLANS: {
    VIP_0: { daily: 0, minInvestment: 0 },
    VIP_1: { daily: 1, minInvestment: 5 },
    VIP_2: { daily: 2.5, minInvestment: 10 },
    VIP_3: { daily: 4, minInvestment: 25 },
    VIP_4: { daily: 8, minInvestment: 50 },
    VIP_5: { daily: 10, minInvestment: 65 },
    VIP_6: { daily: 15, minInvestment: 85 },
    VIP_7: { daily: 25, minInvestment: 100 },
    VIP_8: { daily: 35, minInvestment: 200 },
    VIP_9: { daily: 60, minInvestment: 500 },
    VIP_10: { daily: 85, minInvestment: 750 },
    VIP_11: { daily: 100, minInvestment: 1000 },
    VIP_Bronze: { daily: 200, minInvestment: 2000 },
    VIP_Silver: { daily: 400, minInvestment: 4000 },
    VIP_Golden: { daily: 700, minInvestment: 7000 },
    VIP_Diamond: { daily: 1000, minInvestment: 10000 }
  }
};